# Brightdesk Office Suite — locked product scope

**Status: User-approved and fixed.** This document is the canonical scope control for product planning and implementation.

## The only approved applications

1. **Brightdesk Pages** — document creation and editing (Word-style workflows)
2. **Brightdesk Sheets** — spreadsheets and calculations (Excel-style workflows)
3. **Brightdesk Decks** — presentations (PowerPoint-style workflows)
4. **Brightdesk Notes** — notebooks and notes (OneNote-style workflows)
5. **Brightdesk Database** — relational database tools (Access-style workflows)
6. **Brightdesk Forms** — forms, surveys and quizzes
7. **Brightdesk Lists** — structured lists and record tracking
8. **Brightdesk Planner** — plans, boards and task scheduling
9. **Brightdesk To Do** — personal tasks and reminders
10. **Brightdesk Workspace** — connected pages and project workspaces (Loop-style workflows)

## Permanently excluded

- Outlook
- OneDrive
- Teams
- ArtCraft creative-suite applications
- Every other Microsoft 365, creative, communications, cloud-storage or business application not named in the approved ten-app list above

## Hard rules

- The executable app catalogue must contain exactly the ten approved IDs: `pages`, `sheets`, `slides`, `notes`, `database`, `forms`, `lists`, `planner`, `todo`, `loop`.
- User-facing product names must use the Brightdesk names above. Microsoft product names may appear only as internal workflow/file-format research references where necessary; they must not be used as Brightdesk app names or branding.
- No excluded or other out-of-scope application may appear in the app catalogue, navigation, App Centre, optional features, standalone build scripts, installers or release products.
- Only apps with implemented, persisted and tested workflows may be marked available or built as standalone installers. Planned apps must not be represented as finished or downloadable.
- The user has granted standing permission for routine Brightdesk dependency, coding, testing and build-preparation work. This does not authorise changing the approved app scope.
- The scope can change only when the user explicitly instructs that it should change.

## Current implementation status

- Editing foundations: Brightdesk Pages, Sheets, Decks and Notes.
- Planned, not yet implemented: Brightdesk Database, Forms, Lists, Planner, To Do and Workspace.
- The source snapshot is still a development build; no production installer is claimed by this scope lock.
