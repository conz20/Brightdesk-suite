# Brightdesk 0.3.7 — protected worldwide spelling dictionary catalogue

This catalogue lists the 92 dictionary variants from the pinned `wooorm/dictionaries` snapshot (2024-09-09). These are dictionary variants, not a claim that every language spoken worldwide has a supported dictionary.

The licence column records the upstream dictionary package expression. Each installed dictionary keeps its licence text and upstream package README. The current `nspell` engine is only a subset of Hunspell; compatibility remains subject to runtime validation. Dictionary content, licence terms and attribution are protected read-only resources. End users can select a language but cannot import, edit, relicense, replace or remove dictionaries.

| Language / variant | Locale | Upstream package | Declared licence |
|---|---|---|---|
| Bulgarian | `bg` | `dictionary-bg` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Breton | `br` | `dictionary-br` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Catalan | `ca` | `dictionary-ca` | `(GPL-2.0 OR LGPL-2.1)` |
| Catalan (Valencia) | `ca-ES-valencia` | `dictionary-ca-valencia` | `(GPL-2.0 OR LGPL-2.1)` |
| Czech | `cs` | `dictionary-cs` | `GPL-2.0` |
| Welsh | `cy` | `dictionary-cy` | `LGPL-3.0` |
| Danish | `da` | `dictionary-da` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| German | `de` | `dictionary-de` | `(GPL-2.0 OR GPL-3.0)` |
| German (Austria) | `de-AT` | `dictionary-de-at` | `(GPL-2.0 OR GPL-3.0)` |
| German (Switzerland) | `de-CH` | `dictionary-de-ch` | `(GPL-2.0 OR GPL-3.0)` |
| Greek | `el` | `dictionary-el` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Greek (Polyton) | `el-polyton` | `dictionary-el-polyton` | `GPL-3.0` |
| English | `en` | `dictionary-en` | `(MIT AND BSD)` |
| English (Australia) | `en-AU` | `dictionary-en-au` | `(MIT AND BSD)` |
| English (Canada) | `en-CA` | `dictionary-en-ca` | `(MIT AND BSD)` |
| English (United Kingdom) | `en-GB` | `dictionary-en-gb` | `(MIT AND BSD)` |
| English (South Africa) | `en-ZA` | `dictionary-en-za` | `LGPL-2.1` |
| Esperanto | `eo` | `dictionary-eo` | `GPL-2.0` |
| Spanish | `es` | `dictionary-es` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Argentina) | `es-AR` | `dictionary-es-ar` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Bolivia) | `es-BO` | `dictionary-es-bo` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Chile) | `es-CL` | `dictionary-es-cl` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Colombia) | `es-CO` | `dictionary-es-co` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Costa Rica) | `es-CR` | `dictionary-es-cr` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Cuba) | `es-CU` | `dictionary-es-cu` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Dominican Republic) | `es-DO` | `dictionary-es-do` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Ecuador) | `es-EC` | `dictionary-es-ec` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Guatemala) | `es-GT` | `dictionary-es-gt` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Honduras) | `es-HN` | `dictionary-es-hn` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Mexico) | `es-MX` | `dictionary-es-mx` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Nicaragua) | `es-NI` | `dictionary-es-ni` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Panama) | `es-PA` | `dictionary-es-pa` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Peru) | `es-PE` | `dictionary-es-pe` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Philippines) | `es-PH` | `dictionary-es-ph` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Puerto Rico) | `es-PR` | `dictionary-es-pr` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Paraguay) | `es-PY` | `dictionary-es-py` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (El Salvador) | `es-SV` | `dictionary-es-sv` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (United States) | `es-US` | `dictionary-es-us` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Uruguay) | `es-UY` | `dictionary-es-uy` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Spanish (Venezuela) | `es-VE` | `dictionary-es-ve` | `(GPL-3.0 OR LGPL-3.0 OR MPL-1.1)` |
| Estonian | `et` | `dictionary-et` | `LGPL-2.1` |
| Basque | `eu` | `dictionary-eu` | `GPL-2.0` |
| Persian | `fa` | `dictionary-fa` | `Apache-2.0` |
| Faroese | `fo` | `dictionary-fo` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| French | `fr` | `dictionary-fr` | `MPL-2.0` |
| Friulian | `fur` | `dictionary-fur` | `GPL-2.0` |
| Western Frisian | `fy` | `dictionary-fy` | `GPL-3.0` |
| Irish | `ga` | `dictionary-ga` | `GPL-2.0` |
| Scottish Gaelic | `gd` | `dictionary-gd` | `GPL-3.0` |
| Galician | `gl` | `dictionary-gl` | `GPL-3.0` |
| Hebrew | `he` | `dictionary-he` | `AGPL-3.0` |
| Croatian | `hr` | `dictionary-hr` | `(LGPL-2.1 OR SISSL)` |
| Hungarian | `hu` | `dictionary-hu` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Armenian | `hy` | `dictionary-hy` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Western Armenian | `hyw` | `dictionary-hyw` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Interlingua | `ia` | `dictionary-ia` | `GPL-3.0` |
| Interlingue | `ie` | `dictionary-ie` | `Apache-2.0` |
| Icelandic | `is` | `dictionary-is` | `CC-BY-SA-3.0` |
| Italian | `it` | `dictionary-it` | `GPL-3.0` |
| Georgian | `ka` | `dictionary-ka` | `MIT` |
| Korean | `ko` | `dictionary-ko` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Latin | `la` | `dictionary-la` | `GPL-2.0` |
| Luxembourgish | `lb` | `dictionary-lb` | `EUPL-1.1` |
| Lithuanian | `lt` | `dictionary-lt` | `BSD-3-Clause` |
| Latgalian | `ltg` | `dictionary-ltg` | `LGPL-2.1` |
| Latvian | `lv` | `dictionary-lv` | `LGPL-2.1` |
| Macedonian | `mk` | `dictionary-mk` | `GPL-3.0` |
| Mongolian | `mn` | `dictionary-mn` | `LPPL-1.3c` |
| Norwegian Bokmål | `nb` | `dictionary-nb` | `GPL-2.0` |
| Low German | `nds` | `dictionary-nds` | `GPL-3.0` |
| Nepali | `ne` | `dictionary-ne` | `LGPL-2.1` |
| Dutch | `nl` | `dictionary-nl` | `(BSD-3-Clause OR CC-BY-3.0)` |
| Norwegian Nynorsk | `nn` | `dictionary-nn` | `GPL-2.0` |
| Occitan | `oc` | `dictionary-oc` | `GPL-2.0` |
| Polish | `pl` | `dictionary-pl` | `(GPL-3.0 OR LGPL-3.0 OR MPL-2.0)` |
| Portuguese | `pt` | `dictionary-pt` | `(LGPL-3.0 OR MPL-2.0)` |
| Portuguese (Portugal) | `pt-PT` | `dictionary-pt-pt` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Romanian | `ro` | `dictionary-ro` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Russian | `ru` | `dictionary-ru` | `BSD-3-Clause` |
| Kinyarwanda | `rw` | `dictionary-rw` | `GPL-3.0` |
| Slovak | `sk` | `dictionary-sk` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1)` |
| Slovenian | `sl` | `dictionary-sl` | `(GPL-3.0 OR LGPL-2.1)` |
| Serbian | `sr` | `dictionary-sr` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1 OR CC-BY-SA-3.0)` |
| Serbian (Latin script) | `sr-Latn` | `dictionary-sr-latn` | `(GPL-2.0 OR LGPL-2.1 OR MPL-1.1 OR CC-BY-SA-3.0)` |
| Swedish | `sv` | `dictionary-sv` | `LGPL-3.0` |
| Swedish (Finland) | `sv-FI` | `dictionary-sv-fi` | `LGPL-3.0` |
| Turkmen | `tk` | `dictionary-tk` | `Apache-2.0` |
| Klingon | `tlh` | `dictionary-tlh` | `Apache-2.0` |
| Klingon (Latin script) | `tlh-Latn` | `dictionary-tlh-latn` | `Apache-2.0` |
| Turkish | `tr` | `dictionary-tr` | `MIT` |
| Ukrainian | `uk` | `dictionary-uk` | `GPL-3.0` |
| Vietnamese | `vi` | `dictionary-vi` | `GPL-2.0` |

## Protected catalogue boundary

Only the pinned catalogue can add dictionaries in the user interface. New sources, word-list changes, licence changes, and attribution changes must be reviewed and added by the Brightdesk maintainers in an application release. The built-in 92 variants are not every language spoken worldwide.

Source repository: https://github.com/wooorm/dictionaries
Pinned revision: `8cfea406b505e4d7df52d5a19bce525df98c54ab`
Snapshot date: `2024-09-09`
