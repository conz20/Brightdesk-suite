# Brightdesk public-product workflow research scope

This document records the public-product workflow references used to shape Brightdesk. It is a behavioural/product-architecture study, not a copy of Microsoft source code or proprietary implementation.

## The only approved Brightdesk apps

- Word-style workflows -> **Brightdesk Pages**
- Excel-style workflows -> **Brightdesk Sheets**
- PowerPoint-style workflows -> **Brightdesk Decks**
- OneNote-style workflows -> **Brightdesk Notes**
- Access-style workflows -> **Brightdesk Database**
- Forms-style workflows -> **Brightdesk Forms**
- Lists-style workflows -> **Brightdesk Lists**
- Planner-style workflows -> **Brightdesk Planner**
- To Do-style workflows -> **Brightdesk To Do**
- Loop-style workflows -> **Brightdesk Workspace**

## Permanent exclusions and scope lock

Outlook, OneDrive and Teams are excluded. ArtCraft creative applications and all other Microsoft 365 or business/creative applications not listed above are also outside the approved scope. Do not add, rename, hide, optionally expose or package excluded products. Any scope change requires the user's explicit instruction.

## Design principles

1. One Brightdesk suite with independently installable applications.
2. Familiar workflows with original Brightdesk names, visual design, source code and assets.
3. Local-first documents and projects.
4. No mandatory subscription for core use.
5. Open-source code and dependency licence checks remain mandatory.
6. Protected dictionary/licence resources remain governed by the existing protection policy.
