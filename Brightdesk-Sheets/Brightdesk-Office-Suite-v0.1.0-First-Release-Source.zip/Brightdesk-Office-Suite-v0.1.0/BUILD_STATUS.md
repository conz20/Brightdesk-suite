# Latest update — Node.js 24.22.2 provisioning implementation (2026-11-01)

Implemented in source (not yet installed on this isolated host):
- Added SHA-256-verified official Node.js 24.22.2 provisioning for macOS/Linux (`scripts/install-node24.sh`) and Windows (`scripts/install-node24.ps1`). Toolchains install under the user's home directory and do not replace a system-wide Node.js installation.
- Added `scripts/activate-node24.sh` for macOS/Linux shell activation and PowerShell session activation in the Windows installer.
- Added `npm run setup:dev` to create a genuine lockfile when absent, verify it against the package manifest, run `npm ci`, verify licence notices and run tests.
- Updated both platform setup wrappers and Dev Container post-create to use the shared bootstrap. The Linux prerequisite setup now selects either `libfuse2`/`libasound2` or their `t64` package names according to the distribution's package index.
- Added regression tests for runtime pins, checksum verification and bootstrap ordering.

Latest source verification (using the bundled Node.js 24.11.1 compatibility binary, not the required 24.22.2 runtime):
- Automated tests: **73 passed, 0 failed, 1 skipped** (opt-in network-backed dictionary test).
- JavaScript syntax checks: passed for all files under `src`, `scripts` and `tests`.
- POSIX shell syntax and Linux installer syntax: passed.
- `package.json` and Dev Container JSON parsing: passed.
- Exact runtime guard: correctly rejected 24.11.1. The development bootstrap also stopped before making changes because the exact required version was not active.
- New Linux/macOS installer attempt: stopped at download with DNS error 6 for `nodejs.org`; no unverified runtime archive was extracted. PowerShell is not available for a live Windows script test.
- Release preflight: **BLOCKED by 5 confirmed items** — exact Node.js 24.22.2, missing lockfile, missing `node_modules`, missing Electron and missing electron-builder. App scope, legal documents, installer-consent gates and native Linux host checks passed.
- Local REA Bench static inspection: **94 files, 0 pattern findings**. This is static source inspection only, not external REA or security certification.

Environment status remains distinct from project configuration: the active host PATH is still Node.js 22.16.0, the Playwright-bundled compatibility runtime is Node.js 24.11.1, and neither satisfies the exact 24.22.2 requirement. This host cannot resolve the official Node.js/npm endpoints, so the new installer cannot complete its download here. No dependency lockfile, node_modules tree or native installer is claimed as produced. The connected GitHub account still has no accessible Brightdesk repository.

## Latest verified state — Node.js 24.22.2 pipeline preparation (2026-11-01)

- Default tool-container runtime on `PATH`: Node.js `22.16.0`. A separate Node.js `24.11.1` binary bundled inside Playwright was found and used for a compatibility pass; it is not the required exact Node.js `24.22.2` patch. The Brightdesk runtime guard correctly rejects both the default Node 22 and any Node version other than 24.22.2.
- `npm test`: **68 passed, 0 failed, 1 skipped** under Node.js 22.16.0, and the same **68 passed, 0 failed, 1 skipped** under the bundled Node.js 24.11.1 compatibility runtime. This is not a Node.js 24.22.2 verification run.
- JavaScript syntax checks passed across `src`, `scripts` and `tests`. Bash syntax checks passed for the Node setup, dependency setup and Linux installer scripts. YAML/JSON parsing passed for build-release, security-audit, Dependabot and Dev Container configuration.
- Local REA Bench static inspection: **88 files, 0 pattern findings**. This is a static source check, not a remote REA tool run, runtime trace or security certification.
- `npm run release:preflight` correctly remains **BLOCKED by five items** when run under the bundled Node.js 24.11.1 compatibility runtime: it requires exactly 24.22.2; `package-lock.json` is missing; `node_modules` is missing; Electron is missing; and electron-builder is missing. The default PATH Node.js 22.16.0 is also rejected. All app-scope, legal-agreement and native-host checks passed.
- Provisioning attempts: `nvm install 24.22.2` could not list/download the release; `nodejs.org`, registry.npmjs.org and tested Node mirrors fail DNS resolution from this host. `container.download` attempts also failed. No Docker, Podman, Skopeo or Crane runtime is installed.
- A pre-existing 108 MB npm cache was found, but it does not contain Brightdesk's pinned packages. An offline lock-generation test failed at uncached `docx`; no fabricated lockfile was written.
- GitHub connector returned zero accessible repositories, and a public repository search for `brightdesk-suite` returned none. GitHub Actions cannot be triggered until the actual Brightdesk repository is connected/published. No Windows, macOS or Linux installer has been built or tested.

The three-platform workflow is prepared to generate one genuine lockfile on a connected GitHub runner and use the same lock for each native build. Workflow preparation is not evidence that Node 24 was installed or that CI ran.

See [`NODE24_PROVISIONING_REPORT.md`](NODE24_PROVISIONING_REPORT.md) for the complete runtime provisioning attempts, compatibility test evidence and remaining blockers.

# Brightdesk 0.1.0 — release readiness

**Status: DEVELOPMENT SOURCE SNAPSHOT — NOT READY FOR GENERAL INSTALLATION.**

## Version and source lineage

- Suite version: `0.1.0` (development prerelease).
- Consolidated from the latest saved `0.5.0-repair-source` tree, the `0.5.0` source archive, and the `0.4.1` source archive.
- File comparison confirms that every file in the 0.4.1 source tree is present in the latest tree; the 0.5.0 source tree is the direct base, with its later file-service and project-validation changes retained. Earlier full-code text exports are historical snapshots, not additional modules to concatenate over newer source files.
- Outlook, OneDrive and Teams are excluded from the product catalogue.

## Verified in this environment

- Historical verification is retained below; see the latest verified state at the top for the current test result.
- `node --check` passed for JavaScript files under `src`, `scripts` and `tests`.
- Source ZIP integrity checks passed for the saved 0.4.1, 0.5.0 and 0.5.0 repair archives.
- The app catalogue is now hard-limited to the ten approved Brightdesk apps. Pages, Sheets, Decks and Notes are the only apps marked available; Database, Forms, Lists, Planner, To Do and Workspace remain planned.
- The current source package version and visible shell/core-app version labels are aligned to `0.1.0`.

## Not verified / release blockers

1. The four core editors are basic foundations and do not have full feature parity or all workflows in `APP_IMPLEMENTATION_MATRIX.md`.
2. Brightdesk Database, Forms, Lists, Planner, To Do and Workspace are not implemented as usable apps. They remain planned and must not be presented as ready.
3. Dependencies are not installed in this environment; `npm run verify:licenses` has not passed against a real installed dependency tree. A committed `package-lock.json` is still missing. No reproducible `package-lock.json` is present in this source snapshot; CI now has a dedicated lock-resolution job.
4. The available host runtime is Node.js 22.16.0; the project now strictly requires Node.js 24.22.2. A Node 24 Dev Container and nvm setup script are configured, but the container has not been built and a local Node 24 binary could not be downloaded because `nodejs.org` DNS resolution failed.
5. Windows, macOS and Linux installers have not been built or smoke-tested.
6. Code signing/notarisation and actual release publication have not been completed.
7. No connected REA reverse-engineering tool run is evidenced. The source review is static/manual only and must not be described as an REA result.

## Release decision

Do not distribute this snapshot as a finished Brightdesk release. It is suitable for source review and continued development only. A release requires the remaining app workflows, Node 24 dependency installation and licence audit, reproducible lockfile, native CI builds, and installation/smoke tests on each target operating system.

## Product scope lock

- `PRODUCT_SCOPE_LOCK.md` is the canonical user-approved scope: exactly ten Brightdesk apps, with all other products excluded. Regression tests check that the executable catalogue matches this lock.


## Suite experience direction

- Brightdesk uses the high-level ArtCraft-style family model: focused individual apps, one shared App Centre/launcher, a consistent design system and independent app distribution only when each app is complete.
- This is not an expansion of product scope and does not permit copying ArtCraft or Microsoft code, artwork, names, trademarks or proprietary assets. The exact ten-app lock remains unchanged.
- The contributor rules now direct future work to the installed REA guidance for authorised reverse-engineering tasks and coding-assistant guidance for implementation/review, while requiring actual tool availability and test evidence.

## Release-pipeline hardening (2026-11-01)

- Added `scripts/release-preflight.js` to fail closed on an unsupported Node version, missing committed lockfile, missing installed Electron/build dependencies, catalogue scope drift, or unsupported build host.
- Added `scripts/verify-release-artifacts.js` to require the expected installer formats for each platform and generate SHA-256 checksums.
- Added automated tests for version checks, preflight blockers and installer artifact verification.
- Updated native GitHub Actions builds to require `package-lock.json` and use `npm ci`, run the preflight/tests/licence audit, build only the suite installer, verify the output formats, and upload verified artifacts.
- Removed automatic standalone app installer builds from the release workflow. The six planned apps and the four basic editor foundations are not ready to be marketed as finished independent products.
- **Still blocked in this environment:** Node 22.16.0 rather than 24+, no package lock, no dependency tree, and npm registry DNS failure (`EAI_AGAIN`). No installers have been produced. The project also has no verified connected GitHub repository, so native CI has not run.


## Latest verification after release-pipeline changes

- `npm test`: 55 passed, 0 failed.
- `node --check` passed across JavaScript files in `src`, `scripts` and `tests`.
- `npm run rea:inspect`: 66 files inspected, 0 static pattern findings (`reports/rea/latest.md`). This is static source inspection only, not an external REA engine run.
- `npm run release:preflight`: correctly blocked. Five blockers: Node 22.16.0 (needs 24+), no committed `package-lock.json`, no installed dependencies, no Electron, and no electron-builder. Product-scope checks passed: exact ten IDs, four available foundations, six planned, excluded apps absent.
- `npm ping` failed with DNS `EAI_AGAIN` for `registry.npmjs.org`; dependency installation and lockfile generation cannot currently complete in this environment.
- No `.exe`, `.dmg`, `.zip`, `.AppImage` or `.deb` installer has been created or smoke-tested. Native CI cannot be triggered because no connected repository has been verified.


## Installer agreement and distribution hardening — 2026-11-01

Implemented in the current source tree:
- Added `TERMS_AND_CONDITIONS.txt`, preserving MIT source-code permissions and explicitly stating free use/no activation code.
- Windows NSIS uses the terms file as its licence page.
- macOS build now includes native `.pkg` with Installer licence acceptance, plus `.dmg` and `.zip` formats.
- Linux includes a `.deb` agreement helper with an explicit Yes/No prompt; AppImage and DMG use a first-launch agreement gate.
- Added an app-level first-launch agreement window. Acceptance is stored with the terms SHA-256 and timestamp; changed terms require renewed acceptance; declining exits.
- Release preparation copies Terms, MIT LICENSE and third-party notices into release assets. Artifact verification requires all platform formats and legal documents and writes SHA-256 sums.
- Public tag workflow now requires Windows signing and macOS application/installer signing plus notarisation secrets before publishing.

Verification in this environment:
- `node --test`: 59 passed, 0 failed.
- JavaScript syntax checks and Linux installer `bash -n`: passed.
- REA Bench static inspection: 76 files, zero static pattern findings (not runtime reverse engineering or security certification).
- Release preflight: blocked by Node 22.16.0 (<24), missing package-lock.json, missing node_modules, missing Electron and missing electron-builder.
- npm lockfile generation was attempted but the environment could not resolve the npm registry or nodejs.org; no fake lockfile or installer was created.
- Codex Security Cloud bootstrap returned access denied / no connected GitHub identity, so no cloud security scan was run. The linked GitHub account lists no repositories.
- No Windows/macOS/Linux installer has yet been built or OS-installation-tested. Signing/notarisation secrets have not been configured or verified.

## CI workflow integration — 2026-11-01

- Integrated the supplied pull-request-safe signing environment: Windows/macOS signing and Apple notarisation secrets are blank for pull-request builds and are only passed to non-PR builds.
- Kept the existing weekly Dependabot updates and scheduled high-severity npm audit workflow. Both correctly require the committed dependency lockfile.
- Fixed release artifact collection so Linux, Windows and macOS downloads remain in separate artifact directories. This prevents each platform's identically named `SHA256SUMS.txt`, `LICENSE`, Terms and third-party notices from overwriting another platform's files during GitHub Release publication.
- Added `tests/release-workflows.test.js` to check weekly dependency updates, lockfile-based audits, the three platform build/verification commands, pull-request secret isolation, platform-specific signing credentials and separate artifact downloads.
- Verification: `node --test` — **65 passed, 0 failed**.

### Remaining release blockers

- No `package-lock.json` exists. The npm cache contains unrelated packages but not the required Brightdesk package metadata, and this environment currently has Node.js 22.16.0 rather than the required Node.js 24. The dependency lock cannot be safely generated offline.
- No `node_modules`, Electron or electron-builder installation is present, so native installer builds cannot run here.
- The workflow has not run on GitHub Actions because no accessible Brightdesk repository is connected. Signing/notarisation secrets are not configured or verified.
- No `.exe`, `.dmg`, `.pkg`, `.AppImage` or `.deb` installer has been produced or OS-tested.


## Additional regression coverage and maintenance tooling — 2026-11-01

- Replaced `tests/installer-agreement.test.js` with platform-aware Linux installer tests. The interactive installer tests now skip explicitly outside Linux with Bash 4+, rather than failing on unsupported hosts. On this Linux/Bash 5 environment, both decline and explicit-Yes flows passed using isolated command shims.
- Replaced `tests/app-catalog.test.js` with the supplied expanded scope and packaging checks, including independent app IDs, native macOS PKG/DMG/ZIP targets, app launch locking and rejection of unknown build identifiers.
- Added opt-in `tests/dictionary-service-live.test.js`. It is deliberately skipped in the normal offline suite and runs only when `BRIGHTDESK_LIVE_DICT_TESTS=1`; it requires installed `nspell`/`jszip` dependencies and network access to the pinned upstream dictionary.
- Added `scripts/fix-app-js.js` and the `npm run fix:app-js` command. The cleanup is idempotent: already-removed legacy blocks are reported as absent rather than causing a failure on repeat runs.
- Preserved the existing release history and blocker details in this document rather than replacing them with a shorter status file.

Verification after these changes:
- `npm test`: **65 passed, 0 failed, 1 skipped**. The skipped test is the opt-in network-backed live dictionary integration test; it was not represented as a successful live download.
- `node --check` passed for JavaScript files under `src`, `scripts` and `tests`.
- `npm run fix:app-js` ran twice successfully and made no further source changes because the three legacy fragments were already absent.
- `npm run rea:inspect`: 79 files inspected, 0 static findings. This is local static inspection only; no connected external REA analysis tool or runtime trace was available.

Release blockers remain unchanged: Node.js 24+, a real lockfile/dependency install, native platform builds, OS installation tests, signing/notarisation and a connected GitHub repository are still required before general release.

- Added `PROJECT_MEMORY.md` as the project-local record of the owner’s standing integration instructions, plugin-use permission, fixed product scope and current release baseline; linked it from `AGENTS.md`. The latest local static REA Bench run after these additions inspected 80 files with 0 findings.

## Node.js 24 environment work — 2026-11-01

- Added a reproducible Dev Container based on `node:24-bookworm`, including Linux/Electron packaging prerequisites.
- Added `scripts/use-node24.sh`, `scripts/check-node24.js` and `NODE24_DEVELOPMENT_ENVIRONMENT.md`.
- Enforced Node.js 24.x through `.nvmrc`, `.node-version`, `package.json` (`>=24.0.0 <25.0.0`) and `.npmrc` (`engine-strict=true`).
- **Environment status: configured, not yet provisioned.** Host is still Node.js 22.16.0; `nvm install 24` failed because this environment cannot resolve `nodejs.org`. Docker/Podman is not available here to build the Dev Container.
- No dependency lockfile was generated, no npm dependencies were installed, and no installer build was run during this update.


## Node.js 24.22.2 and shared-lock CI update — 2026-11-01

- Standardised every supported development/CI environment on exact Node.js **24.22.2 LTS**.
- Added `scripts/verify-lockfile.js`; added `npm run lock:prepare` and `npm run lock:verify`.
- CI now resolves a genuine dependency lockfile on one Node 24.22.2 runner, verifies it against `package.json`, then passes that same lock to all three native builds and uses `npm ci`. A tagged release carries the exact lockfile as build metadata.
- Dependency security audit now creates/validates the same kind of lockfile before install/audit.
- Local Node 24.22.2 installation remains blocked by environment outbound DNS/download restrictions; only an older Playwright-bundled Node 24.11.1 runtime is present. No Docker/Podman runtime is available. npm offline lock generation failed because `docx` and other required project package metadata are not cached.
- The connected GitHub account exposes no repositories, so CI could not be triggered. No platform installers were produced by this update.


## Pages page setup foundation — 2026-11-01

- Added a dedicated page-layout model for A4, US Letter and US Legal paper sizes, portrait/landscape orientation, and narrow/normal/moderate/wide margin presets.
- Added page setup controls to the Brightdesk Pages Layout ribbon and persisted settings inside the Pages document model.
- Added four focused unit tests covering defaults, dimensions, margin values and safe fallback for invalid settings.
- Verification on this workbench: `node --check src/app.js`, `node --check src/page-layout.js`, and `npm test` passed (77 passed, 0 failed, 1 optional network test skipped) under Node.js 22.16.0. This is not the required Node.js 24.22.2 environment and does not constitute installer verification.
- Pages remains incomplete against the full acceptance matrix; no app availability status or installer eligibility was changed.
