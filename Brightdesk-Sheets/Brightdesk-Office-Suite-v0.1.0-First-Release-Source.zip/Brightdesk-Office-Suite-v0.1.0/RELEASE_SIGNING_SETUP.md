# Brightdesk release signing setup

The public release workflow intentionally refuses to publish unsigned Windows or unnotarised macOS installers. Configure these as **GitHub Actions repository secrets** in the Brightdesk source repository before creating a `v*` release tag.

## Windows

- `WIN_CSC_LINK` — base64-encoded or file-backed PKCS#12 (`.p12`/`.pfx`) Authenticode signing certificate supported by electron-builder.
- `WIN_CSC_KEY_PASSWORD` — password for that certificate.

## macOS

- `MAC_CSC_LINK` — Developer ID Application certificate for signing the `.app` bundle.
- `MAC_CSC_KEY_PASSWORD` — password for the application certificate.
- `MAC_INSTALLER_CSC_LINK` — separate Developer ID Installer certificate for signing `.pkg` installers.
- `MAC_INSTALLER_CSC_KEY_PASSWORD` — password for the installer certificate.
- `APPLE_ID` — Apple developer account email used for notarisation.
- `APPLE_APP_SPECIFIC_PASSWORD` — app-specific password for notarisation.
- `APPLE_TEAM_ID` — Apple Developer Team ID.

Do not commit certificates, passwords, app-specific passwords or private keys to the repository or source ZIP. Add them only through the repository's encrypted Actions secrets interface. The workflow does not print secret values.

## Linux

Linux `.deb` and `.AppImage` builds are verified with SHA-256 checksums. The release currently does not require a Linux package-signing key; a future GPG signing setup should publish a detached signature and its public verification key.

## Repository connection

The source repository must be available to the authenticated GitHub Actions account, and the workflow file must be committed to its default branch. The release process cannot run until a real repository has been connected and the build workflow has passed on native Windows, macOS and Linux runners.
