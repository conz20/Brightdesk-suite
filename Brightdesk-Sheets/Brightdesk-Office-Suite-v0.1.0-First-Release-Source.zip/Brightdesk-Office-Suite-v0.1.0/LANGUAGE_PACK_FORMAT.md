# Brightdesk language-pack format

A Brightdesk language pack is a UTF-8 JSON file with the `.bdlang` extension. The same JSON structure is also accepted with a `.json` extension.

```json
{
  "code": "fr-FR",
  "name": "French (France)",
  "nativeName": "Français (France)",
  "direction": "ltr",
  "proofingCode": "fr",
  "translations": {
    "language.title": "Paramètres linguistiques",
    "language.description": "Installez des packs linguistiques.",
    "language.displayTitle": "Langue d’affichage",
    "language.proofingTitle": "Langue de vérification",
    "language.installedTitle": "Packs installés",
    "language.availableTitle": "Packs disponibles",
    "sidebar.languages": "Langues",
    "sidebar.yourApps": "VOS APPLICATIONS",
    "top.open": "Ouvrir",
    "top.export": "Exporter"
  }
}
```

Requirements:

- `code` must be a language tag such as `fr-FR` or `pt-BR`.
- `name` and `nativeName` are required.
- `direction` must be `ltr` or `rtl` (it defaults to `ltr`).
- `proofingCode` is optional. It should be a dictionary language code supported by the target Electron build.
- `translations` must contain 10–1,000 string entries. Missing translation keys fall back to English (Australia).
- Each translation key is limited to letters, numbers, dots, underscores and hyphens. Each value may be up to 1,000 characters.
- The file must be 256 KB or smaller.
- `en-AU` is reserved as the default language and cannot be imported over or removed.

The language pack must contain translated interface text only. It is not executable code and cannot load scripts, plugins or fonts.
