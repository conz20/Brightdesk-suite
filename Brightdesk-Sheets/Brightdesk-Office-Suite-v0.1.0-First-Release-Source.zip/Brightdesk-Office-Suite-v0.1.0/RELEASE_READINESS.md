# Brightdesk 0.1.0 — release readiness

**Status: DEVELOPMENT SOURCE SNAPSHOT — NOT READY FOR GENERAL INSTALLATION.**

## Latest verified state — 2026-11-01

- The project is pinned to **Node.js 24.22.2 LTS** across npm engines, `.nvmrc`, `.node-version`, Dev Container, setup scripts and GitHub Actions. The default host `PATH` remains Node.js 22.16.0. A separate Playwright-bundled Node.js 24.11.1 executable was found and used only for compatibility testing; it does not satisfy the exact 24.22.2 pin.
- `npm test`: **68 passed, 0 failed, 1 skipped** under Node.js 22.16.0 and independently **68 passed, 0 failed, 1 skipped** under the bundled Node.js 24.11.1 runtime. Neither is an exact Node.js 24.22.2 build verification.
- JavaScript syntax, relevant Bash script syntax and workflow/Dev Container YAML/JSON validation passed.
- Local REA Bench static review: 87 files, 0 pattern findings; not an external REA run or security certification.
- Release preflight: **BLOCKED** by the wrong local Node version, missing lockfile, missing dependency tree, missing Electron and missing electron-builder. Product scope, app agreements, licensing documents and Linux native-host checks passed.
- Attempts to install Node 24.22.2 failed because the container cannot resolve nodejs.org, npm registry or the tested mirror hosts. NVM could not resolve the release list and returned `Version 24.22.2 not found`. The container has no Docker/Podman runtime. Offline npm lock generation failed on uncached `docx`; no placeholder lockfile was created.
- GitHub connector shows no accessible repository; no public `brightdesk-suite` repository was found in the connected GitHub search. Consequently, the updated GitHub Actions workflow has not run and no native installers were built, signed, notarised or smoke-tested.

## Version and source lineage

- Suite version: `0.1.0` (development prerelease).
- Consolidated from the latest saved `0.5.0-repair-source` tree, the `0.5.0` source archive, and the `0.4.1` source archive.
- File comparison confirms that every file in the 0.4.1 source tree is present in the latest tree; the 0.5.0 source tree is the direct base, with its later file-service and project-validation changes retained. Earlier full-code text exports are historical snapshots, not additional modules to concatenate over newer source files.
- Outlook, OneDrive and Teams are excluded from the product catalogue.

## Verified in this environment

- `npm test`: 59 passed, 0 failed (Node.js 22.16.0).
- `node --check` passed for JavaScript files under `src`, `scripts` and `tests`.
- Source ZIP integrity checks passed for the saved 0.4.1, 0.5.0 and 0.5.0 repair archives.
- The app catalogue is hard-limited to Brightdesk Pages, Sheets, Decks, Notes, Database, Forms, Lists, Planner, To Do and Workspace. Only Pages, Sheets, Decks and Notes are marked available; the other six remain planned.
- The current source package version and visible shell/core-app version labels are aligned to `0.1.0`.

## Not verified / release blockers

1. The four core editors are basic foundations and do not have full feature parity or all workflows in `APP_IMPLEMENTATION_MATRIX.md`.
2. Brightdesk Database, Forms, Lists, Planner, To Do and Workspace are not implemented as usable apps. They remain planned and must not be presented as ready.
3. Dependencies are not installed in this environment; `npm run verify:licenses` has not passed against a real installed dependency tree. No reproducible `package-lock.json` is present.
4. The available runtime is Node.js 22.16.0; the project requires Node.js 24.22.2.
5. Windows, macOS and Linux installers have not been built or smoke-tested.
6. Code signing/notarisation and actual release publication have not been completed.
7. No connected REA reverse-engineering tool run is evidenced. The source review is static/manual only and must not be described as an REA result.

## Release decision

Do not distribute this snapshot as a finished Brightdesk release. It is suitable for source review and continued development only. A release requires the remaining app workflows, Node 24 dependency installation and licence audit, reproducible lockfile, native CI builds, and installation/smoke tests on each target operating system.


## Installer agreement and licence workflow — 2026-11-01

- `TERMS_AND_CONDITIONS.txt` is the human-readable agreement. Brightdesk remains MIT-licensed, free of charge and does not require an activation code, product key, subscription or account.
- Windows NSIS setup displays the terms and requires acceptance.
- macOS produces a native `.pkg` with an Installer licence page, as well as `.dmg` and `.zip` formats. Standalone app builds also request `.pkg`.
- Linux produces `.deb` and `.AppImage`; `Brightdesk-Install-Linux.sh` displays the agreement and requires Yes before installing the `.deb`.
- A first-launch agreement window covers DMG/AppImage and any other install route. It records the terms SHA-256 and asks again if the text changes. No means the app exits.
- Release assets include `LICENSE`, `TERMS_AND_CONDITIONS.txt` and `THIRD_PARTY_NOTICES.md`; artifact verification requires the platform formats and legal files and writes SHA-256 checksums.
- Public Windows/macOS tags require code-signing and macOS notarisation secrets. See `RELEASE_SIGNING_SETUP.md`.

Latest verification: 59 tests pass; JavaScript syntax, Linux shell syntax and workflow YAML checks pass; static REA Bench inspected 76 files with zero pattern findings. These are source-level checks, not native installer tests.

Still blocked: Node 24 is not installed here (runtime is Node 22.16.0); package-lock.json and node_modules are absent; npm registry and nodejs.org DNS lookups fail from this build container; Electron/electron-builder are therefore unavailable. GitHub connection has no accessible repository, and Codex Security Cloud bootstrap denied access. No native installers have been produced, signed, notarised or installed on target operating systems. Do not distribute this development snapshot as a completed release.


Legal note: `TERMS_AND_CONDITIONS.txt` is a project draft prepared for the installer flow. It has not been reviewed by a qualified lawyer. Before a public release, have the final terms and privacy/data-handling statements reviewed for the jurisdictions where Brightdesk will be distributed.

## CI workflow integration — 2026-11-01

- Integrated the supplied pull-request-safe signing environment: Windows/macOS signing and Apple notarisation secrets are blank for pull-request builds and are only passed to non-PR builds.
- Kept the existing weekly Dependabot updates and scheduled high-severity npm audit workflow. Both correctly require the committed dependency lockfile.
- Fixed release artifact collection so Linux, Windows and macOS downloads remain in separate artifact directories. This prevents each platform's identically named `SHA256SUMS.txt`, `LICENSE`, Terms and third-party notices from overwriting another platform's files during GitHub Release publication.
- Added `tests/release-workflows.test.js` to check weekly dependency updates, lockfile-based audits, the three platform build/verification commands, pull-request secret isolation, platform-specific signing credentials and separate artifact downloads.
- Verification: `node --test` — **65 passed, 0 failed**.

### Remaining release blockers

- No `package-lock.json` exists in this snapshot. An older npm cache is present, but the pinned Brightdesk package metadata is not cached; offline generation stopped at `docx`. The dependency lock cannot be safely generated offline.
- No `node_modules`, Electron or electron-builder installation is present, so native installer builds cannot run here.
- The workflow has not run on GitHub Actions because no accessible Brightdesk repository is connected. Signing/notarisation secrets are not configured or verified.
- No `.exe`, `.dmg`, `.pkg`, `.AppImage` or `.deb` installer has been produced or OS-tested.
