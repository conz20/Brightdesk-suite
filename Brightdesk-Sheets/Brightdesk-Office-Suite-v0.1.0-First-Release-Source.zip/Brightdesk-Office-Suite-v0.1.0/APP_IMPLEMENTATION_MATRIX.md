# Brightdesk app implementation matrix

This is the fixed product scope and definition of done. No app outside this list may be added to the catalogue, navigation, installer scripts or product roadmap without the user's explicit change to this decision. `available` means useful workflows are implemented, persisted, tested and usable; a placeholder is not sufficient.

| Brightdesk app | Product reference (research only) | Required first useful workflows | Current source status |
|---|---|---|---|
| Brightdesk Pages | Word | Rich document editing; styles; lists/tables/images; page layout; spell check; DOCX/HTML/PDF export; DOCX import | Basic editor foundation; A4/Letter/Legal page size, portrait/landscape and margin presets added; incomplete parity |
| Brightdesk Sheets | Excel | Multi-sheet workbook; cell editing; formula engine; ranges; sort/filter; formatting; charts; XLSX/CSV import/export | Basic grid and limited formulas; incomplete parity |
| Brightdesk Decks | PowerPoint | Slide thumbnails/reorder; layouts; themes; text/images/shapes; transitions; presenter mode; PPTX import/export | Basic title/body slides; incomplete parity |
| Brightdesk Notes | OneNote | Notebooks/sections/pages; rich notes; checklists; tags; search; attachments; export/import | Basic text notes; incomplete parity |
| Brightdesk Database | Access | Tables, typed fields, relationships, queries, forms, reports and CSV import/export | Not implemented |
| Brightdesk Forms | Forms | Form designer, question types, validation, branching, preview, response collection and export | Not implemented |
| Brightdesk Lists | Lists | Typed columns, views, filters, sorting, grouping, templates and record editing | Not implemented |
| Brightdesk Planner | Planner | Plans, buckets, task cards, assignments, priorities, dates, labels, progress and board/schedule views | Not implemented |
| Brightdesk To Do | To Do | Lists, tasks, subtasks, due dates, reminders, recurrence, My Day and completed tasks | Not implemented |
| Brightdesk Workspace | Loop | Pages, components, linked task/list blocks, workspace navigation and local-first project data | Not implemented |

## Availability rule

Only apps with complete, tested first-use workflows may be marked `available` or included in standalone installer builds. The six planned apps remain visible as planned work, not as finished or downloadable products. Outlook, OneDrive and Teams are permanently excluded. All apps use Brightdesk names and original branding.
