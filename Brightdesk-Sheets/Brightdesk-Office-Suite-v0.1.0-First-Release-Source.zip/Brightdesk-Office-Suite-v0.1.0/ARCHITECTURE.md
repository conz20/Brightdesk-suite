# Brightdesk — System Architecture

**Status:** Target architecture for implementation; existing code only partially matches it.

## Product shape

A single Electron desktop shell hosts independent Brightdesk app modules. The shell owns navigation, app lifecycle, settings, local file dialogs, update handling and shared accessibility/localisation services. Each app owns its document model, editor, commands, import/export adapters and tests.

```mermaid
flowchart TD
  U[User] --> S[Brightdesk desktop shell]
  S --> A[App registry and routing]
  A --> W[Word module]
  A --> X[Excel module]
  A --> P[PowerPoint module]
  A --> N[OneNote module]
  A --> M[Other app modules]
  W --> D[(Local project store)]
  X --> D
  P --> D
  N --> D
  M --> D
  S --> F[Validated file service]
  F --> D
  S --> L[Language and dictionary services]
  S --> U2[Native OS integration]
```

## Existing verified components

| Component | Existing code | Current responsibility |
|---|---|---|
| Desktop main process | `src/main.js` | Electron window, IPC handlers, file dialogs, language/dictionary services, updater |
| Preload bridge | `src/preload.js` | Narrow renderer API via `contextBridge` |
| Renderer shell | `src/app.js`, `src/index.html`, `src/styles.css` | App navigation, editor UI, state and localStorage persistence |
| App registry | `src/app-catalog.js` | Product catalogue and availability status |
| File adapters | `src/file-service.js` | DOCX/XLSX/CSV/PPTX/text import/export |
| Formula engine | `src/formula.js` | Spreadsheet formula evaluation |
| Language service | `src/language-service.js` | Built-in language pack validation and metadata |
| Dictionary service | `src/dictionary-service.js` | Protected dictionary catalogue and spell checking |
| Packaging | `package.json`, `electron-builder.app.config.js`, `.github/workflows/build-release.yml` | Suite and four standalone app packaging configuration |

## Required target contracts

- `AppDefinition`: stable ID, display metadata, module version, status, capabilities and supported file types.
- `AppModule`: editor view, command/ribbon definition, validated document schema, migrations, import/export adapters and test suite.
- `DocumentStore`: versioned per-app data, atomic writes, backups, recovery and migration handling.
- `FileService`: format-specific adapters, size limits, schema validation, safe archive/XML parsing and explicit warnings for lossy imports.
- `IPC`: sender validation, strict payload schemas, bounded input sizes and allow-listed operations.
- `Installer`: same tested suite shell across OSes, with optional standalone app packages generated from the same tested modules.

## Data and security boundaries

- The renderer is untrusted. Do not expose Node APIs or filesystem paths directly.
- All file access occurs through the main process after sender and payload validation.
- Imported HTML must be sanitised before it reaches an editor. Imported project JSON must be validated against a versioned schema before merging into state.
- Archives and documents must have compressed and uncompressed size limits, entry-count limits and safe path handling.
- User content remains local by default. Optional cloud or AI features must be opt-in and clearly identify data sent outside the device.
- The language and dictionary protection policy remains separate from editable user documents and must not be weakened by app modules.

## Persistence and portability

Move from renderer-only `localStorage` to a versioned local document store in the Electron main process. Keep `localStorage` for small preferences only. Use atomic writes, backups, explicit schema versions and recovery on malformed or interrupted saves. Project bundles must include all module data needed to reopen a workspace and must never silently discard unknown future fields.

## Packaging and delivery

- Build the full suite on native Windows, macOS and Linux runners.
- Build optional standalone app packages from the same source and test matrix; do not duplicate app code.
- Upload platform-specific artifacts with unique names and attach them to a tagged release only after every required job succeeds.
- Keep auto-update disabled until a real repository owner, release channel and signed/notarised update policy are configured.
- Record unsigned status accurately when signing secrets are absent.
