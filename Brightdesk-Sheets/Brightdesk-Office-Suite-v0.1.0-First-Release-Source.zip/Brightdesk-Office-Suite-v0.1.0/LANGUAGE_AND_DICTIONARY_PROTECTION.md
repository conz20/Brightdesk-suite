# Brightdesk language and dictionary protection — 0.3.7

## What ordinary users can change

- Choose Brightdesk's display language from the bundled language-pack catalogue.
- Choose the proofing language for their documents.
- Install an available, official dictionary from the built-in 92-entry catalogue.
- Choose which installed dictionary is used for spelling checks.

## What ordinary users cannot change

- Dictionary word lists or Hunspell affix rules.
- A dictionary's licence expression or licence text.
- The original dictionary source URL, revision, author or contributor information.
- The contents of bundled interface-language packs.
- Replace or overwrite an installed dictionary or language pack.
- Import a custom dictionary or language pack through Brightdesk.
- Remove a protected dictionary or language pack through Brightdesk.

## Technical controls

- The renderer no longer exposes import or removal controls for these resources.
- The preload bridge no longer exposes import/removal methods.
- Corresponding main-process IPC handlers have been removed.
- Catalogue dictionary manifests must match the exact locale, source URL, pinned repository revision, upstream identity and licence expression in the app-bundled catalogue.
- New dictionary installations store SHA-256 integrity hashes for the installed affix, word list, licence and attribution files. Brightdesk checks these hashes before listing or using a dictionary.
- Legacy 0.3.6 catalogue installs must be compared with their pinned upstream dictionary, licence and README before the integrity record is added.
- Dictionary and language files are given read-only permissions where the operating system supports them.
- Reinstalling an existing locale does not replace it. A protected dictionary can only change through a reviewed Brightdesk application release.

## Important security boundary

This protects resources from changes through Brightdesk and detects ordinary on-disk tampering for new installations. It cannot stop the owner or administrator of a computer from changing local files, changing permissions, modifying the installed application or running a modified build. Stronger resistance to a device owner would require platform code signing, trusted updates and an external trust anchor. No desktop application can promise that local administrators are unable to modify files they control.
