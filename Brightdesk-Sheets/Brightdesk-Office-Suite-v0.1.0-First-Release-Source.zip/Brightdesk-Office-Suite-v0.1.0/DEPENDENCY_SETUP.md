# Brightdesk dependency setup

Brightdesk builds require exactly Node.js 24.22.2 and the dependency versions pinned in `package.json`. Electron and electron-builder are project development dependencies; do not install global copies.

## Windows (PowerShell)

1. Open PowerShell in the Brightdesk project folder.
2. Run the runtime installer and activate it in the current PowerShell session:

   `. .\scripts\install-node24.ps1`

3. Run the dependency setup:

   `npm run setup:dev`

Or run the combined wrapper, which installs/activates Node.js 24.22.2 if necessary and then performs dependency setup:

`powershell -ExecutionPolicy Bypass -File .\scripts\setup\install-dependencies.ps1`

## macOS and Linux (Terminal)

From the Brightdesk project folder, run:

```sh
bash scripts/setup/install-dependencies.sh
```

The wrapper installs the official Node.js 24.22.2 binary into `~/.brightdesk/toolchains/` if the exact version is not already active, verifies the archive against the official SHA-256 manifest, activates it for the setup process, then runs the dependency bootstrap. It does not replace the system Node.js installation.

To install/activate Node.js separately:

```sh
. scripts/use-node24.sh
```

## What dependency setup does

`npm run setup:dev` checks the exact Node.js version, generates a real `package-lock.json` if it is missing, verifies that lockfile against `package.json`, installs dependencies with `npm ci`, verifies licence notices and runs the tests. An internet connection to the official Node.js distribution and npm registry is required when provisioning the runtime or downloading uncached dependencies.

Linux setup also installs Electron packaging prerequisites through `apt-get` and requests administrator approval through `sudo`. Windows installers must be built on Windows, macOS installers on macOS, and Linux packages on Linux. The GitHub Actions workflow uses native runners for all three systems.

## Important

Do not create or edit `package-lock.json` by hand. If the npm registry is unavailable, dependency setup must stop and report the network failure rather than invent package integrity values. The project remains on Node.js 24.22.2; Node.js 22 and other Node.js 24 patch versions are unsupported.
