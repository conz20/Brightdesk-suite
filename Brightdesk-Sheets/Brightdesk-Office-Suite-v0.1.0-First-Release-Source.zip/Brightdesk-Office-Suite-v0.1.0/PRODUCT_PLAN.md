# Brightdesk Office Suite — Product Plan

**Outcome:** A local-first desktop suite containing exactly ten independently named Brightdesk productivity apps, with familiar office workflows, original design and a route to individual Windows, macOS and Linux downloads.

**Status:** Active build specification; not a claim that every app is implemented.
**Scope rule:** This ten-app list is fixed. Do not add creative-suite, extra business, communications, cloud-storage or other applications unless the user explicitly changes the scope.

## Approved applications

| Brightdesk app | Public workflow reference |
|---|---|
| Brightdesk Pages | Word |
| Brightdesk Sheets | Excel |
| Brightdesk Decks | PowerPoint |
| Brightdesk Notes | OneNote |
| Brightdesk Database | Access |
| Brightdesk Forms | Forms |
| Brightdesk Lists | Lists |
| Brightdesk Planner | Planner |
| Brightdesk To Do | To Do |
| Brightdesk Workspace | Loop |

The reference names are for research and compatibility planning only. User-facing names, branding, code and assets must be Brightdesk originals.

## Permanently excluded

- Outlook
- OneDrive
- Teams
- Any other Microsoft 365 app/service not in the approved ten-app list
- ArtCraft creative apps and unrelated extra applications

## First-release journey

Install Brightdesk App Centre or an individual Brightdesk app → open it → create or import a file → edit it → save locally → reopen it → export to a compatible format. Each app must be independently installable when its own acceptance checks are complete.

## Product requirements

| ID | Requirement | Priority | Acceptance check |
|---|---|---:|---|
| P-01 | Provide a unified Brightdesk shell and App Centre | Must | User can find, open, switch between and manage only the ten approved apps |
| P-02 | Complete Brightdesk Pages | Must | Create, edit, format, save, reopen, import and export documents; preserve supported formatting |
| P-03 | Complete Brightdesk Sheets | Must | Edit cells, use formulas, sort/filter, format tables, save/reopen and import/export workbooks |
| P-04 | Complete Brightdesk Decks | Must | Create, reorder, duplicate, delete, design, present, save/reopen and import/export decks |
| P-05 | Complete Brightdesk Notes | Must | Create notebooks, sections and pages; organise notes, checklists, search and save/reopen them |
| P-06 | Build Brightdesk Database | Should | Create tables/fields/relations, add/edit records, query, forms and reports |
| P-07 | Build Brightdesk Forms | Should | Design forms and quizzes, validate submissions, collect and export responses |
| P-08 | Build Brightdesk Lists | Should | Create typed columns, views, filters, sorting, grouping and record workflows |
| P-09 | Build Brightdesk Planner | Should | Plans, buckets, task assignments, priorities, dates, progress and board/schedule views |
| P-10 | Build Brightdesk To Do | Should | Personal lists, tasks, subtasks, due dates, reminders and completion views |
| P-11 | Build Brightdesk Workspace | Should | Combine pages, lists, tasks and components into reusable project workspaces |
| P-12 | Provide local storage and project portability | Must | User can save, reopen, back up and export projects without an account or subscription |
| P-13 | Provide independent installers | Must | Each completed app can be installed separately on Windows, macOS and Linux; suite installer remains optional |
| P-14 | Preserve exclusions | Must | Excluded apps and all out-of-scope products are absent from catalogue, navigation, package and installer outputs |
| P-15 | Preserve language and dictionary protections | Must | Existing immutability, licence and source checks remain passing |

## Release sequencing

1. Stabilise desktop foundation, dependencies, persistence, import/export and cross-platform CI.
2. Complete Brightdesk Pages, Sheets, Decks and Notes.
3. Build Brightdesk Database, Forms, Lists, Planner, To Do and Workspace.
4. Produce individual installers only for apps that pass their acceptance checks.
5. Test installation, upgrades, data round-trips and uninstall behaviour on each supported operating system.

## Success criteria

- Exactly ten approved apps appear in the product scope.
- No placeholder app is labelled as ready or downloadable.
- Every available app passes its own feature tests and data round-trip tests.
- Users can install only the apps they want.
- Local-first work remains available without a subscription or forced account.
- Outlook, OneDrive, Teams and all other out-of-scope apps remain absent.

## Engineering and legal boundaries

Brightdesk is independent software. Research visible workflows in products the investigator is authorised to inspect. Do not copy proprietary source code, protected assets, trademarks, private APIs or bypass licensing/access controls. Keep Brightdesk's own licensing and all third-party licence notices intact.
