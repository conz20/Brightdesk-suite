# Brightdesk Office Suite 0.1.0

Brightdesk is an independent office-style productivity suite for Windows, macOS and Linux. Its interface uses familiar desktop productivity patterns—an app launcher, document title bar, ribbon tabs, grouped commands, formula bar, slide workspace and document canvas—while keeping its own Brightdesk identity, names, icons and original implementation. It is not Microsoft Office, is not affiliated with Microsoft, and does not include Microsoft software or subscription services.

## Applications

- **Pages** — rich-text editing, local autosave, DOCX/HTML export, DOCX/HTML/TXT/MD import and PDF export.
- **Sheets** — editable grid, formula bar, basic `SUM`, `AVERAGE`, `MIN`, `MAX`, `COUNT`, `COUNTA` and arithmetic formulas, XLSX/CSV import and export.
- **Decks** — create, edit, add, duplicate, delete and present slides; PPTX import and export (text content is imported; advanced layouts, media and transitions are not preserved).
- **Notes** — quick notes, local autosave and Markdown/TXT export.
- **Brightdesk project** — save and reopen the entire workspace in `.bdesk` format.

## Installable language packs

Open **Languages** in the Brightdesk sidebar to choose the Brightdesk display language and spelling language. The bundled choices are English (Australia), French (France), German (Germany) and Spanish (Spain). The display language changes Brightdesk menus, ribbon tabs, common commands and setup screens straight away; no restart is needed.

Display language and proofing language are separate settings. For example, you can keep Brightdesk menus in English while checking a document in French. Windows and Linux use Electron/Chromium Hunspell dictionaries when a matching dictionary is available; Electron may need an internet connection to download a dictionary the first time it is selected. macOS uses the spelling languages configured by macOS. If a proofing dictionary is not available, Brightdesk still sets the editor's language tag, but cannot promise spelling suggestions for that language.

Language packs are copied from Brightdesk’s bundled catalogue and checked against the original packaged files. Users can select the display and proofing languages, but cannot import, edit, replace, relicense or remove the bundled language resources.

The included language packs are installed from the local Brightdesk catalogue and work offline. This version does not yet have a hosted online language-pack store or automatic language-pack updates. Custom pack structure and validation rules are documented in `LANGUAGE_PACK_FORMAT.md`.

## Open-source spelling dictionaries

Open **Languages** in the sidebar and scroll to **Spelling dictionaries**. Brightdesk can install dictionary entries only from its pinned, built-in catalogue. User imports and removal are disabled. The catalogue keeps each dictionary’s original word list, licence expression, licence text, source URL and contributor README together.

After installing a dictionary, choose it in **Check the current document** and run a check on Pages, Sheets, Decks or Notes. The check is offline. It reports possible misspellings and suggestions; it does not automatically change document text. The existing operating-system spell checker remains available as well.

Brightdesk now includes a searchable catalogue of **92 Hunspell dictionary variants** from the [wooorm/dictionaries collection](https://github.com/wooorm/dictionaries). This includes regional variants such as English (Australia), English (Canada), German (Austria), Spanish (Mexico), Serbian (Latin script) and Portuguese (Portugal). The collection itself explains that its normalised package repository is not the maintainer of each dictionary and that each dictionary keeps its own original licence. Brightdesk preserves the source licence text and upstream source URL when installing. Estonian and Basque use the canonical GNU LGPL-2.1 and GPL-2.0 licence texts, bundled unchanged, because their package folders do not contain an individual `license` file. The catalogue is pinned to a Git revision for reproducible downloads.

The 92 entries are not every language spoken in the world. Many languages do not yet have a redistributable Hunspell dictionary, and languages with complex or no space-based word segmentation need additional tokenizer and spelling-engine work. The current `nspell` engine is a useful subset of Hunspell, so a catalogue entry is not a promise that every linguistic feature is supported. Unsupported dictionaries are not marked installed. Users may install and select a catalogue language, but the dictionary words, licence terms, source attribution and author records are read-only. Only a new signed or otherwise trusted Brightdesk application release can change the built-in catalogue. The complete list of 92 variants is in `WORLD_LANGUAGE_DICTIONARIES.md`; the bundle format is documented in `DICTIONARY_PACK_FORMAT.md`.

## First launch and app setup

All four apps—Pages, Sheets, Decks and Notes—are included in the desktop installer and are activated automatically on a fresh installation. After installing Brightdesk, users can open the suite straight away without completing a separate app-selection wizard. The **Get apps** screen remains available from the sidebar if users later want to hide or restore an app. Hiding an app does not delete its local documents.

The approved catalogue contains exactly ten products: Brightdesk Pages, Brightdesk Sheets, Brightdesk Decks, Brightdesk Notes, Brightdesk Database, Brightdesk Forms, Brightdesk Lists, Brightdesk Planner, Brightdesk To Do and Brightdesk Workspace. Only Pages, Sheets, Decks and Notes currently have editing foundations. The other six are planned and must not be shown as finished or installable until their workflows are implemented and tested. Individual installers are built only for completed apps.

## Familiar interface, original software

Brightdesk is designed to feel familiar to users of modern office suites: it has a left app rail, named applications, a document header, Home/Insert/Layout/Review/View-style ribbon tabs, grouped tool commands, spreadsheet formula controls, and slide design/presentation commands. Its UI, source code, names and artwork are Brightdesk originals. It does not use Microsoft logos, proprietary source code, or Microsoft binaries. Research against Microsoft applications should be limited to visible workflows in software the investigator owns or is authorised to inspect; do not bypass licensing or access controls.

## Developer environment — Node.js 24.22.2

Brightdesk development and installer builds use exactly Node.js **24.22.2 LTS**. The project includes checksum-verified installers for macOS/Linux (`scripts/install-node24.sh`) and Windows (`scripts/install-node24.ps1`), a one-command dependency bootstrap (`npm run setup:dev`), and a Dev Container definition. The setup process creates a real npm lockfile only when needed, installs locked dependencies, checks licences and runs tests. See `NODE24_DEVELOPMENT_ENVIRONMENT.md` for the exact steps.

## Cross-platform installers

The project is configured to produce separate downloads:

| Platform | Output |
|---|---|
| Windows x64 | NSIS `.exe` installer |
| macOS Intel + Apple Silicon | Universal `.dmg` and `.zip` |
| Linux x64 | `.AppImage` and `.deb` |

Build on native platform runners. The hardened GitHub Actions workflow in `.github/workflows/build-release.yml` builds the suite installer on Ubuntu, Windows and macOS, runs the release preflight, automated tests and dependency licence audit, verifies the expected installer files, and generates SHA-256 checksums. A tagged release attaches the verified installer files and checksums to a GitHub Release. The workflow creates one real dependency lockfile on a Node.js 24.22.2 runner, verifies it against `package.json`, and shares that same lockfile with all three native platform jobs, which install using `npm ci`. A tagged release also retains the exact lockfile as build metadata.

## Run from source

Requirements: Node.js 24.22.2 and npm. The workflow creates and verifies one `package-lock.json` on a Node.js 24.22.2 runner and shares that exact lockfile across all three native build jobs. For source development, run `npm run lock:prepare` on a network-connected Node.js 24.22.2 environment and commit the reviewed lockfile when possible.

```bash
# First setup only when no package-lock.json is present:
npm run lock:prepare
npm run lock:verify

# Normal repeatable installs after the lockfile exists:
npm ci
npm test
npm start
```

## Build installers separately

Check whether this machine is ready to build (this fails safely when a prerequisite is missing):

```bash
npm run release:preflight
```

Build the full Brightdesk suite:

```bash
npm run dist:win          # Windows x64 NSIS installer (.exe)
npm run dist:mac          # Universal Intel + Apple Silicon macOS (.dmg and .zip)
npm run dist:linux        # Linux x64 AppImage and .deb
```

Standalone app packaging scripts are retained for controlled development checks, but the current editors are still foundations and are not approved for public standalone distribution. The release workflow therefore builds only the suite installer. Independent app downloads will be enabled only after each app meets its implementation-matrix acceptance checks and passes its own install, launch, save/reopen, export and upgrade tests. Do not cross-build macOS packages on Windows/Linux or Windows packages on macOS/Linux; use the matching native runner.


## Releases and automatic updates

1. Create a GitHub repository named `brightdesk-suite` and push this project to its `main` branch.
2. Generate a `package-lock.json` for the approved `package.json` with `npm run lock:prepare`, verify it with `npm run lock:verify`, and commit the reviewed lockfile when working in a network-connected environment. CI can generate a temporary shared lockfile for the three native platform jobs when the source snapshot does not yet contain one.
3. Push the project. Pull requests and pushes run native builds/tests on all three operating systems. Verified installer artifacts and SHA-256 checksums are available from the Actions run.
4. In-app automatic updates remain disabled until you add the actual repository owner to `build.publish` in `package.json` (provider `github`, the correct `owner`, and repo `brightdesk-suite`) and test update metadata on real devices. Do not leave a placeholder owner in a public release.
5. To publish a release, increment `version` in `package.json`, update the affected app's `moduleVersion` in `src/app-catalog.js`, commit, create a matching version tag and push it. For example:

```bash
Do not tag or publish this development snapshot as a release.
```

6. GitHub Actions builds and verifies the Windows, macOS and Linux suite installers and attaches them to the release.

Packaged Brightdesk checks for updates on startup, when its window regains focus (with a five-minute check throttle), and every six hours while it is running. The user can also choose **Check for updates**. Windows and supported macOS/AppImage builds use `electron-updater` to automatically download a published suite release in the background and apply it when Brightdesk restarts or closes. `.deb` users update through their Linux package manager or by installing the latest `.deb`.

**How app updates work:** the suite and each standalone app are separate installable products. A suite release updates the suite; an app-only release process can publish the matching standalone installer. The current workflow builds only the suite package; standalone app releases remain disabled until each app is complete. Automatic in-app update publishing remains disabled until the real GitHub repository owner and release configuration are supplied and tested.

Updates require a real GitHub repository and published releases. Checking every six hours is a periodic check, not instant background monitoring. It does not monitor Microsoft feature announcements or automatically implement new Microsoft features; those need development, testing and a new Brightdesk release.

## Signing and trusted distribution

Unsigned Windows installers may show SmartScreen warnings. macOS releases should be signed with a Developer ID certificate and notarised for the smoothest installation and trusted automatic updates. Configure signing secrets in GitHub Actions before public production releases. Do not distribute release builds until signing and update publication have been tested on real devices.

## Compatibility and known limitations

Version 0.1.0 is the first planned Brightdesk release. It is an early release and not a complete Microsoft 365 replacement. It supports common document, spreadsheet and presentation workflows, but it does not provide full Word/Excel/PowerPoint feature parity. Advanced page layout, macros/VBA, pivot tables, complex formula recalculation, charts, slide themes/animations, embedded media, comments, real-time collaboration, cloud storage and perfect round-trip conversion are not implemented. Import/export may simplify unsupported formatting or objects.

## Application catalogue status

The catalogue is hard-limited to ten Brightdesk apps: Pages, Sheets, Decks, Notes, Database, Forms, Lists, Planner, To Do and Workspace. Pages, Sheets, Decks and Notes are the only apps with editing foundations; the other six remain planned and are not installable until implemented and tested. Outlook, OneDrive, Teams and all other out-of-scope applications are excluded.

## Validation status for this source bundle

The dependency-free unit tests (`npm test`) can run without installing the Office-format conversion libraries. The DOCX, XLSX and PPTX import/export features still require `npm install` to install the dependencies declared in `package.json`. Use Node.js 24.22.2 for the supported desktop development and installer-build environment. The full desktop UI and native installers still need to be built and smoke-tested on their respective operating systems in GitHub Actions. No installer is claimed to have been produced by this source-only bundle.

## Open-source licence and installation verification

Brightdesk itself is released under the MIT License. There are no Brightdesk product keys, serial numbers, paid activation steps or licence-server checks. The Windows NSIS installer displays the MIT licence and requires the user to accept it before continuing. macOS DMG/ZIP and Linux AppImage/DEB packages include the licence and third-party notices, but their standard installation flows do not currently show the same interactive acceptance screen.

After npm dependencies are installed, `postinstall` runs an offline licence audit. The audit checks Brightdesk's MIT notice and each installed dependency's licence metadata or included licence file, then generates `THIRD_PARTY_NOTICES.md`. It flags packages explicitly marked unlicensed/proprietary and packages with no licence metadata or recognised licence file. It does not alter, remove or bypass third-party licence terms, and it is not a legal determination that every dependency is suitable for every distribution model.

The dependency audit requires installed packages, so run `npm ci` from a committed lockfile before `npm run verify:licenses`. No account, activation code or internet-based licence validation is involved in this check.

## License

MIT. See `LICENSE`. Third-party components retain their own licences; see `THIRD_PARTY_NOTICES.md` after dependency installation.

## Product and engineering specifications

- `PRODUCT_PLAN.md` — complete product scope, user journey and release sequence.
- `ARCHITECTURE.md` — current verified components and target module/persistence architecture.
- `APP_IMPLEMENTATION_MATRIX.md` — app-by-app definition of done; unfinished modules must not be marked available.
- `AGENTS.md` — engineering, security and release rules for future coding work.
- `BUILD_STATUS.md` — current implementation state, test evidence and release blockers.


## Product experience direction

Brightdesk is designed as an original, cohesive family of focused productivity apps: an ArtCraft-style app-family and independent-installation model, with a shared Brightdesk App Centre and consistent design system. This does not expand the approved product list. The only apps in scope are the ten listed in `PRODUCT_SCOPE_LOCK.md`; Outlook, OneDrive, Teams and all other unapproved apps remain excluded.


## Installer agreement and licences

Brightdesk is free and open source under the MIT License. No activation code, product key, paid subscription or account registration is required. Read `TERMS_AND_CONDITIONS.txt` before installing. Windows and macOS PKG installers display the agreement in their native setup flow; the Linux `.deb` helper asks for an explicit Yes/No decision. Brightdesk also displays the agreement before first use, including for DMG and AppImage distribution. `LICENSE` and `THIRD_PARTY_NOTICES.md` must ship with every release. Third-party components retain their own licences.

Public release tags are blocked unless Windows signing and macOS Developer ID signing/notarisation credentials are configured. A source ZIP or a passing unit-test suite is not a signed, tested installer release.

## Node.js 24.22.2 development environment

Brightdesk requires exactly Node.js 24.22.2 LTS. The repository includes `.nvmrc`, `.node-version`, strict npm engine enforcement, official checksum-verified runtime installers for Windows/macOS/Linux, and a `.devcontainer` based on the official Node.js 24.22.2 image. On macOS/Linux, source `. ./scripts/use-node24.sh`; on Windows, dot-source `.\scripts\install-node24.ps1`. Then run `npm run setup:dev` to create/verify the dependency lock, install the locked dependencies, check licences and run tests. See [`NODE24_DEVELOPMENT_ENVIRONMENT.md`](NODE24_DEVELOPMENT_ENVIRONMENT.md) for full setup instructions. Node.js 22 and older Node.js 24 patches are not supported for project installation or builds.
