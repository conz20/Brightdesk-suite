const packageConfig = require('./package.json');
const appId = process.env.BRIGHTDESK_APP_ID;
const names = { pages: 'Pages', sheets: 'Sheets', slides: 'Decks', notes: 'Notes' };
if (!Object.hasOwn(names, appId)) throw new Error('Set BRIGHTDESK_APP_ID to one supported app: pages, sheets, slides or notes.');
const appName = names[appId];
module.exports = {
  ...packageConfig.build,
  appId: `org.brightdesk.${appId}`,
  productName: `Brightdesk ${appName}`,
  directories: { ...packageConfig.build.directories, output: `release/apps/${appId}` },
  extraMetadata: { brightdeskAppId: appId, productName: `Brightdesk ${appName}` },
  win: {
    ...packageConfig.build.win,
    artifactName: `Brightdesk-${appName}-Setup-${packageConfig.version}-${'${arch}'}.${'${ext}'}`
  },
  mac: {
    ...packageConfig.build.mac,
    artifactName: `Brightdesk-${appName}-${packageConfig.version}-${'${arch}'}.${'${ext}'}`
  },
  linux: {
    ...packageConfig.build.linux,
    artifactName: `brightdesk-${appId}-${packageConfig.version}-${'${arch}'}.${'${ext}'}`
  },
  appImage: {
    ...packageConfig.build.appImage,
    artifactName: `brightdesk-${appId}-${packageConfig.version}-${'${arch}'}.${'${ext}'}`
  }
};
