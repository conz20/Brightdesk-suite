# Brightdesk 0.3.6 — static source reverse-engineering review

**Review type:** Static analysis of the supplied Brightdesk JavaScript/Electron source.

**Target:** Brightdesk 0.3.6 working source tree.

**Scope:** Application architecture, process boundaries, file flows, language/dictionary subsystem, and security-relevant controls.

**Not performed:** No Electron app was launched, no installer/ASAR was examined, no debugger or process instrumentation was attached, and no third-party office product was inspected. The REA runtime/static-analysis MCP tools were not exposed in this chat, so this is a source-led review rather than a claimed REA tool run.

## 1. Executive findings

Brightdesk is a single-window Electron desktop application. The renderer owns the user interface and editor state, the preload script exposes a narrow `contextBridge` API, and the main process owns filesystem dialogs, office-file conversion, local project I/O, language/dictionary storage, dictionary downloads, and update handling.

The process boundary is sensibly separated: the renderer has `nodeIntegration: false`, `contextIsolation: true`, and `sandbox: true`; window-opening and navigation are denied; and IPC handlers check that the sender is the main window's web contents.

The new dictionary catalogue is data-driven. It has 92 variants from a pinned `wooorm/dictionaries` snapshot dated 9 September 2024. All 92 package folders were verified to contain `.aff`, `.dic`, and `readme.md` files. Other catalogue entries retain their upstream package `license` file. Estonian and Basque do not have a per-package `license` file, so Brightdesk includes the matching standard GNU GPL-2.0/LGPL-2.1 text unchanged with official GNU links. The catalogue is not every language in the world, and a catalogue entry is not a guarantee of full Hunspell compatibility.

The next meaningful engineering step is a runtime trace of Brightdesk itself, followed by a feature-by-feature comparison against a reference application that the user owns or is authorised to inspect. Static source review does not reveal runtime behaviour or prove compatibility with Microsoft Office or another product.

## 2. Architecture map

```mermaid
flowchart TD
  A[Electron main process: src/main.js] --> B[BrowserWindow]
  B --> C[Preload bridge: src/preload.js]
  C --> D[Renderer: src/index.html and src/app.js]
  D --> E[LocalStorage: document and UI state]
  D -->|ipcRenderer.invoke| C
  C -->|IPC channels| A
  A --> F[File service: src/file-service.js]
  A --> G[Language service: src/language-service.js]
  A --> H[Dictionary service: src/dictionary-service.js]
  H --> I[User data folder: installed dictionaries]
  H --> J[Pinned dictionary source: wooorm/dictionaries]
  H --> K[Pinned SPDX license text: et/eu exceptions]
  D --> L[Formula engine: src/formula.js]
  D --> M[App catalogue and i18n]
```

### Main process — `src/main.js`

- Creates a single `BrowserWindow` (initial size 1440 × 920; minimum 980 × 680).
- Loads local `src/index.html` and sets the renderer security preferences.
- Owns IPC endpoints for file open/export, `.bdesk` project save/open, PDF output, language-pack operations, spelling-dictionary operations, and update operations.
- Owns the `DictionaryService` instance and gives it Electron's per-user `app.getPath('userData')` directory.
- Rejects IPC calls whose `event.sender` is not the main window's web contents.
- Performs dictionary downloads in the main process, not in renderer JavaScript.

### Preload boundary — `src/preload.js`

- Exposes `window.brightdesk` through `contextBridge.exposeInMainWorld`.
- Exposes specific methods such as `openFile`, `exportFile`, `saveProject`, `listDictionaries`, `listDictionaryCatalogue`, `installCatalogueDictionary`, `importDictionary`, `removeDictionary`, and `checkSpelling`.
- Does not expose raw `ipcRenderer` or Node filesystem access to the renderer.

### Renderer — `src/index.html`, `src/app.js`, `src/styles.css`

- Provides the app shell, four editors, the app manager, Language Centre, dictionary centre, and update status.
- Keeps the active documents in renderer state and persists them to localStorage under `brightdesk-docs-v3`.
- Saves app selection and completion state separately under `brightdesk-app-setup-v1`.
- Stores display-language, proofing-language, and selected-dictionary preferences separately.
- Renders Pages, Sheets, Decks, and Notes from one shared renderer process.

### Supporting modules

| File | Role observed in source |
|---|---|
| `src/file-service.js` | Opens and exports supported office-style files and `.bdesk` project files. |
| `src/formula.js` | Calculates spreadsheet arithmetic and the implemented basic functions. |
| `src/language-service.js` | Validates display-language translation packs and provides the built-in four-language catalogue. |
| `src/i18n.js` | Applies interface translation strings and falls back to English (Australia). |
| `src/dictionary-service.js` | Validates/imports Hunspell bundles, downloads the built-in catalogue, stores dictionaries, and checks words with `nspell`. |
| `src/dictionary-catalog.json` | Stores 92 dictionary variants, licence expressions, source folders, revisions, and engine support notes. |
| `src/app-catalog.js` | Defines the four application modules and their metadata. |

## 3. Feature traces

### A. Application startup

1. `app.whenReady()` runs in `src/main.js`.
2. The main process creates `DictionaryService` at the user's Brightdesk data location.
3. `createWindow()` creates the Electron window and loads `index.html`.
4. `preload.js` installs the narrow `window.brightdesk` API.
5. `app.js` loads stored document/app settings, renders the workspace, and refreshes language/dictionary data.

### B. Document editing and persistence

1. The renderer edits an in-memory document object for the selected app.
2. Input/change handlers call `persist()`.
3. `persist()` writes the four document objects to localStorage.
4. Project save calls `window.brightdesk.saveProject(...)`, which crosses preload/IPC and opens a native save dialog in the main process.
5. Project open similarly returns data from the main process, then the renderer validates/sanitises the Pages HTML before placing it in the editor.

### C. File import/export

1. The renderer calls `openFile()` or `exportFile(payload)`.
2. Preload forwards the request over a named IPC channel.
3. Main-process handlers validate the sender, show the native dialog, and call `file-service.js`.
4. PDF export uses `webContents.printToPDF()` and writes the returned bytes from the main process.

### D. Dictionary installation

1. The user opens **Languages → Spelling dictionaries**.
2. Renderer calls `listDictionaryCatalogue()`.
3. `dictionaries:catalog` returns installed state joined to the fixed 92-entry JSON catalogue.
4. The user chooses **Install**. Renderer sends only the catalogue ID.
5. Main process checks the sender and calls `DictionaryService.installCatalogueEntry(id)`.
6. The dictionary service resolves the ID from the built-in JSON catalogue, validates its licence expression, downloads the `.aff`, `.dic`, and package `readme.md` from the pinned dictionary source, obtains the licence text either from that package or from a bundled canonical GNU licence file for the two exceptions, and creates a temporary `.bddict` archive.
7. The archive goes through the same validation and `nspell` load check as a manually imported bundle.
8. On success the dictionary is installed under the user's Brightdesk data folder and appears in the installed list.

### E. Spelling check

1. Renderer collects text from the current document. Pages use `innerText`; Notes use the textarea; Decks concatenate slide titles and text; Sheets collect non-formula cell values.
2. Renderer sends `{ locale, text }` through `checkSpelling()`.
3. Main process validates the IPC sender and payload shape.
4. Dictionary service loads/caches the locale's `.aff`/`.dic` dictionary and calls `nspell.correct()` and `nspell.suggest()` for tokens.
5. The renderer reports possible misspellings and suggestions in a dialog. It does not automatically change document content.

## 4. Security and reliability observations

### Positive controls present in source

- Renderer has Node integration disabled, context isolation enabled, and sandbox enabled.
- New windows are denied and page navigation is prevented.
- Main-process IPC handlers check the sender window.
- Built-in dictionary installation accepts a catalogue ID, not an arbitrary URL or local path.
- Dictionary network access is constrained to the pinned raw GitHub dictionary source path; redirects, query strings and hashes are rejected.
- Dictionary downloads have a timeout and independent file-size ceilings.
- Dictionary archives reject nested file paths, validate a manifest, check expected file types, check declared licence identifiers, and validate decoded text before install.
- Dictionary installation stages files before replacing the installed locale folder and attempts to restore the previous folder if replacement fails.
- Imported Pages HTML is reduced to a safe tag/attribute allow-list before it is used in the editor.

### Findings to address before a public release

1. **Dictionary file integrity:** URLs are pinned to source commits and fetched over HTTPS, but the app does not yet verify expected SHA-256 hashes for each downloaded `.aff`, `.dic`, and licence file. Add a hash table to the catalogue before treating downloads as release-grade.
2. **Hunspell feature coverage:** `nspell` is not the complete native Hunspell engine. The UI must continue to state that complex affix, compound, morphology, and segmentation behaviours may be incomplete. A later engine adapter should permit a full Hunspell implementation or a language-specific tokenizer where packaging/licensing permits.
3. **Runtime coverage:** Unit tests cover service rules with test doubles, but the current work has not installed all 92 dictionaries, launched the packaged desktop app, or tested actual native Hunspell behaviour on Windows/macOS/Linux.
4. **Spelling UX:** The current action presents suggestions in a dialog. It does not underline misspellings inline, move between issues, or apply a selected suggestion to the document.
5. **Language coverage:** The text tokenizer is Unicode-letter based. Languages requiring dictionary segmentation or morphology-specific processing need separate engine work. No claim is made for Chinese/Japanese or every world's language.
6. **Release configuration:** `YOUR_GITHUB_ACCOUNT` remains a placeholder in the electron-builder publish configuration. It must be replaced with the actual repository owner before publishing updates.
7. **Third-party licence review:** The local licence audit checks package metadata and notices. It is not legal advice and it does not replace a manual review of third-party terms or the per-dictionary notices.

## 5. Evidence and test limits

- Static syntax checks passed for `src/dictionary-service.js`, `src/main.js`, `src/preload.js`, and `src/app.js`.
- `npm test` passed: 29 tests, 0 failures, 0 skipped.
- Tests cover the 92-entry catalogue count, locale uniqueness, allowed licence expressions, pinned download URL boundaries, size-bounded stream reading, dictionary format checks, spell-check result grouping, office-file helpers, formulas, app metadata, language packs, and the dependency licence verifier.
- The test command ran in a container with Node.js 22.16.0. The project specifies Node.js 24 or later for dependency installation and release builds. No `npm install`, installer build, or signed/notarised package build was run here.
- Dictionary binaries were not downloaded en masse or tested as a complete set in this pass. Catalogue presence is not proof that each dictionary loads correctly in `nspell`.

## 6. Next reverse-engineering phase

The source-led architecture map is complete. The next evidence-based phase is a narrowly scoped runtime trace:

1. Build and launch Brightdesk 0.3.6 on a supported Node.js 24 environment with a clean test user-data directory.
2. Capture the exact user journey for open, save, import, export, dictionary install, spelling check, and app switching.
3. Compare source-level expectations with the observed runtime events and file changes.
4. If comparing a separate office product, identify a specific version and an installation or sample file that the user owns or is authorised to inspect. Compare only visible workflows and file-format behaviour; do not copy proprietary code, bypass protections, or extract restricted assets.

A genuine REA static/runtime tool invocation remains outstanding because those tools were not available in this chat session. The next run should use the REA JavaScript/Electron workflow once the REA tools or documented local CLI are connected and the exact target artefact is supplied.

---

# Brightdesk 0.5.0 — installer and application catalogue review

**Review type:** Manual static inspection of the saved Brightdesk 0.4.1 source ZIP and all-code export, followed by review of the 0.5.0 source changes.

**Target:** `brightdesk-suite-v0.5.0` source tree.

**REA status:** The REA skill guidance was consulted, but the REA analysis tools were not exposed in this ChatGPT session. No `analyze_javascript_application` REA run is claimed. This is a manual source review plus automated project tests, not a REA-generated report.

## Findings

1. The previous catalogue contained 23 app entries, but the renderer only had dedicated editor workflows for `pages`, `sheets`, `slides`, and `notes`. The remaining entries fell through to a generic contenteditable placeholder; `setApp()` also rejected them because they were absent from the core editor configuration. They were not complete independent applications.
2. The 0.5.0 catalogue now marks the four implemented editors as `available` and the remaining catalogue entries as `planned`. The App Centre displays planned entries as **In development** and does not allow them to be selected or installed.
3. The standalone packaging configuration creates a distinct Electron `appId`, product name, output folder, and packaged `brightdeskAppId` for each of the four available apps.
4. The main process passes the packaged app ID to the preload script. The renderer starts directly in the matching editor, hides the app manager, restricts app navigation, and rejects imports whose app kind does not match the standalone product.
5. The full-suite builder configuration remains unchanged apart from the suite version bump. Standalone artifacts are written below `release/apps/<app-id>/` while suite artifacts remain below `release/`.
6. The GitHub Actions workflow builds the suite and four standalone apps on native Windows, macOS and Linux runners and uploads the resulting release directory.

## Verification

- 45 automated tests passed under Node.js 22.16.0.
- JavaScript syntax checks passed for all source, script and test files.
- The release workflow YAML parsed successfully.
- The standalone builder configuration was loaded for all four app IDs and returned distinct IDs, product names and output directories.

## Remaining release gates

- The project requires Node.js 24 or later. The available local runtime is Node.js 22.16.0.
- Dependencies are not installed in this environment; Electron installers were not built.
- The Electron application was not launched for GUI smoke tests.
- No Windows, macOS or Linux installer was smoke-tested on a native operating system.
- Signing/notarisation credentials and the real GitHub repository owner remain unconfigured.
- Planned catalogue apps still require actual feature implementations before being marked available.
