# Brightdesk contributor instructions

> Read `PROJECT_MEMORY.md` for the owner's standing integration instructions, approved plugin-use permission, current project baseline and latest supplied code updates. Keep that project record in sync with meaningful changes.

## Required development runtime
- Brightdesk development, dependency installation and installer builds must use exactly Node.js **24.22.2 LTS**. Node.js 22 and other 24.x patch versions are not accepted.
- Keep `.nvmrc`, `.node-version`, `package.json` `engines.node`, `.npmrc`, `.devcontainer`, and all CI runner versions aligned to `24.22.2`.
- On macOS/Linux, use `. ./scripts/use-node24.sh`; on Windows, dot-source `.\scripts\install-node24.ps1`. The installers verify the official archive checksum and install into the user's home folder rather than replacing the system runtime.
- Run `npm run setup:dev` to generate/verify a real lockfile, install exact dependencies with `npm ci`, verify licences and run tests. Never create a fake lockfile or claim Node 24.22.2 is active without checking `node --version`.

## Product boundary
- Build an independent, local-first desktop productivity suite with original Brightdesk code, names, icons and visual assets.
- Study only public product documentation and authorised, observable user workflows. Never copy Microsoft source code, proprietary binaries, artwork, trademarks, private APIs or confidential implementation details.
- Do not add Outlook, OneDrive or Teams. These are explicit product exclusions.
- Preserve the existing MIT/open-source policy and protected language/dictionary resource rules.
- Do not mark an app `available` until its acceptance checks in `APP_IMPLEMENTATION_MATRIX.md` are implemented and tested.


## ArtCraft-inspired suite experience (not an app-scope expansion)
- Use ArtCraft only as a high-level product-experience reference: a recognisable family of focused apps, a shared app launcher/App Centre, consistent navigation and design language, and independent app downloads where each app is genuinely implemented.
- Keep Brightdesk original: create our own layouts, icons, typography, colours, wording, code and assets. Do not copy ArtCraft or Microsoft source, artwork, interface assets, trademarks, or proprietary implementation.
- Preserve the exact ten approved Brightdesk apps in `PRODUCT_SCOPE_LOCK.md`. ArtCraft is a style/distribution reference, not permission to add creative-suite apps or any other products.
- Make each app feel purpose-built for its own workflow while sharing Brightdesk menus, settings patterns, file handling, accessibility, keyboard conventions and visual components.
- The App Centre must distinguish installed, available-to-install, planned and unavailable apps honestly. Never show a planned app as working or downloadable.

## Standing user direction and authorised project work
- The user has given ongoing permission to carry out the work reasonably needed to recreate the approved Brightdesk product: inspect and edit its source, improve features, fix defects, add tests, update documentation, run safe local checks, and prepare verified source/build outputs. Do not repeatedly ask for permission for routine work already covered by this direction.
- Use relevant installed assistance resources when they materially help: REA Analysis Companion for authorised reverse-engineering planning/evidence interpretation, and Code Assistant / Vibe Coder guidance for coding, debugging, refactoring, testing and project work. Discover and use other installed plugins only when their actual capability is relevant to the current task; do not invoke unrelated plugins merely to claim they were used.
- The user wants an ArtCraft-like suite experience: a family of focused apps, shared launcher/App Centre, consistent design language and independent app downloads. This is a high-level product-model reference only; all Brightdesk code, branding, assets and UI must remain original. The exact ten-app scope in `PRODUCT_SCOPE_LOCK.md` remains locked.
- For authorised shipped-app, archive, Electron/ASAR, binary, runtime or capture questions, consult the installed REA guidance and use an actual REA tool only when its executable capability and schema are exposed in this session.
- The project-local Brightdesk REA Bench is a reproducible static source/scope checker. It is not the external REA engine and must not be represented as binary decompilation, runtime tracing or a security certification.
- A skill or guide is not itself an executing coding agent or analysis engine. Verify changes against this repository's source, tests and build constraints; state clearly when a required plugin engine/tool is not connected.
- User permission covers work on the Brightdesk project and materials they provide or are authorised to use. It does not imply permission to bypass third-party licensing, access controls, accounts, private systems or confidential code, or to run untrusted targets without the required safety checks.
- Record findings as observed, inferred or unknown; retain evidence and limitations in project reports.

## Current-session plugin and verification workflow
- At the start of a substantial Brightdesk task, inspect the plugins/tools actually available in the current session. Availability can change between sessions; do not assume a plugin is connected merely because its guide is installed.
- Select every plugin that materially helps the specific task, but do not invoke unrelated plugins just to maximise plugin count. Examples: AI Task Brief Builder for turning requirements into testable acceptance criteria; REA guidance/tools for authorised shipped-artifact analysis; Code Assistant/Vibe Coder guidance for implementation prompts and coding workflow; Codex Security Cloud and AI Application Security for relevant security reviews when the project/workspace is connected; GitHub tools for repository/PR/CI work only when the user's repository is actually connected; Stark developer tools for plugin/skill metadata validation; Website Launch Check only for a deployed public website; Video Code Reviewer for a requested code walkthrough. Domain-specific tools for aquariums, proteins, fitness, date/decimal normalisation, or unrelated personal workflows are not Brightdesk coding tools unless a concrete task genuinely calls for them.
- Before repeating a test, review, plan or scan, check whether matching accepted evidence already exists; reuse valid evidence and rerun only when code, requirements, dependencies, configuration or environment has materially changed.
- Work in small, reviewable changes. For each change: define expected behaviour and acceptance checks; inspect affected code; implement; run relevant tests and static checks; run `npm test`; run `npm run rea:inspect` for substantial source/scope changes; run licence checks when dependencies are available; inspect the diff; update the app implementation matrix, build status and changelog as appropriate.
- For security-sensitive or high-risk changes, include an independent review where available. Do not treat a passing unit-test suite, static scan, route plan, completion receipt or plugin skill as proof of full correctness or security.
- Report exactly what ran, what passed, what failed, what could not run, and what remains unverified. Correct actionable errors before calling the task complete. Never claim a build, external REA analysis, security scan, CI run or independent review happened unless its tool actually returned evidence.
- The user's ongoing permission covers routine Brightdesk source edits, safe local tests, documentation and project checks. Actions with external side effects (publishing, merging, deploying, spending, changing account permissions, installing software, or running an untrusted target) remain subject to the relevant tool permissions and safety checks.

## Engineering rules
- Keep Electron main, preload and renderer responsibilities separate. Keep `contextIsolation: true`, `nodeIntegration: false`, and the narrow preload API.
- All privileged operations must be validated in the main process and must reject calls from non-main-window senders.
- Treat imported files, project files, HTML, archive contents and renderer payloads as untrusted. Validate structure, sizes and types before processing.
- Keep user documents local by default. Do not add cloud accounts, telemetry, paid subscriptions or external sync without an explicit product decision.
- Keep app data isolated by module and support safe project export/import.
- Avoid `eval`, dynamic code execution, unsafe HTML insertion and unbounded archive extraction.
- Every feature change must include meaningful unit or integration tests and update the app matrix.

## Required checks
1. `npm test`
2. `npm run verify:licenses` after dependencies are installed
3. `node --check` for changed JavaScript files
4. Native packaging on Windows, macOS and Linux CI runners
5. Smoke-test install, launch, save, reopen, export and uninstall/upgrade behavior on each supported platform

Do not describe a release as ready based only on unit tests. Record blocked checks and manual tests in `BUILD_STATUS.md`.

## Brightdesk REA Bench workflow
- For every substantial source-scope or implementation review, run `npm run rea:inspect` and retain the Markdown/JSON evidence under `reports/rea/`.
- Treat this as Brightdesk's local static inspection helper, not the external REA engine. Never claim runtime tracing or binary reverse engineering from its output.
- Use authorised targets only; record observations separately from inferences and unknowns.

## Release build integrity
- Require a committed `package-lock.json` and use `npm ci`; do not silently resolve floating transitive dependencies during release builds.
- Run `npm run release:preflight` before packaging. A failed preflight means no installer should be described as ready.
- Build suite installers only until each standalone app has passed its own implementation-matrix acceptance checks and install/launch/save/reopen/export/upgrade smoke tests.
- After native packaging, run the matching `npm run release:verify:<platform>` script and retain its SHA-256 checksum output.
- Never claim code signing, macOS notarisation, automatic updates, native installation, or upgrade behaviour passed unless the actual platform evidence exists.


## Owner-authorised installer and release work (2026-11-01)

The project owner explicitly authorises the assistant to use relevant installed plugins, coding tools, security tools, build environments and test tools for Brightdesk without asking again for routine implementation, dependency, configuration, debugging or verification steps. Make reasonable changes needed to complete the approved product and release workflow. This standing permission does not authorise paid purchases, new third-party accounts, accepting external legal terms on the owner's behalf, exposing credentials, bypassing platform security/licensing, or publishing a public release without the required signing credentials and verified release gates.

Release installer requirements:
- Free and open-source distribution under the MIT licence; no activation code, product key, paid subscription, licence server or account registration.
- Every installer must include `LICENSE`, `TERMS_AND_CONDITIONS.txt` and the generated `THIRD_PARTY_NOTICES.md` dependency inventory.
- Windows NSIS installer must display the terms and require an explicit agreement before installation.
- macOS native `.pkg` installer must display the terms and require agreement; keep `.dmg` and `.zip` as additional distribution formats. The application must also show the agreement before first use for DMG installs.
- Linux `.deb` installation helper must display the terms and require an explicit Yes/No choice before installing. Keep `.deb` and `.AppImage`; the app-level first-launch gate applies to AppImage use.
- The app-level agreement is version/hash-bound, stored in the user's application data, and must be accepted again when the terms text changes. Declining exits without opening the suite.
- Verify all expected platform artifacts, non-zero sizes and SHA-256 checksums before upload. Public tagged releases require Windows code-signing and macOS Developer ID application/installer signing plus notarisation credentials. Do not publish unsigned binaries as a finished general-public release.
- Only the four currently implemented apps (Pages, Sheets, Decks, Notes) may be offered as working apps until the remaining six are genuinely implemented and tested. The ten-app product scope remains fixed.
- Keep build evidence honest: a passing unit suite or static scan is not a native installer build, OS installation test, notarisation result or full product-readiness result.
