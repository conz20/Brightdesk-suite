# Brightdesk REA Bench

Brightdesk includes its own small, dependency-free inspection utility called **Brightdesk REA Bench**. It is a project-local source and package evidence tool inspired by the user's requested Reverse Engineer Anything workflow. It supports the wider Brightdesk development process alongside the installed REA guidance and coding-assistant skill resources, but does not replace either executable analysis engines or real build/test tools. It is not the external REA product, does not register an MCP server, and does not replace binary reverse-engineering or runtime tracing.

## Run it

```sh
npm run rea:inspect
```

Or inspect another authorised source directory:

```sh
node scripts/brightdesk-rea.js inspect /path/to/source
```

It inventories files, records SHA-256 hashes, reads package metadata, checks the executable app catalogue against Brightdesk's fixed ten-app scope, and flags selected risky Electron/source patterns. Reports are written to `reports/rea/latest.md` and `reports/rea/latest.json`.

## Evidence rules

- Use only software, source, packages and systems the user owns or is authorised to inspect.
- Start with inventory and metadata; narrow the inspection to the relevant feature or module.
- Separate direct observations, inferences and unknowns.
- Static source patterns are not proof of runtime behavior.
- Do not run unknown binaries, bypass licensing or access controls, extract secrets, or inspect third-party systems without permission.
- Do not describe this utility as the external REA engine or claim runtime/binary analysis.
- If actual REA MCP/CLI tools become available, inspect their advertised schemas and use them for authorised shipped-binary/runtime questions; keep this local bench as the reproducible source inventory and scope check.

## Current boundaries

This tool does not execute the target, decompile binaries, attach debuggers, trace runtime calls, probe networks, or determine legal licence compatibility. Its report is a static review aid, not a security certification.


## Suite-design reference

Brightdesk follows the high-level ArtCraft-style product model requested by the user: a family of focused, independently installable apps, brought together by one consistent launcher/App Centre and shared design system. This is a product-organisation and experience reference only. Brightdesk uses original branding, interface design, code and assets, and remains limited to the ten apps in `PRODUCT_SCOPE_LOCK.md`.
