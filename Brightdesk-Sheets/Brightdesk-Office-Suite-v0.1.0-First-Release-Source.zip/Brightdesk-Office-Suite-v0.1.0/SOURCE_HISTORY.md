# Brightdesk source history and first-release versioning

Brightdesk is being prepared for its first public release as version `0.1.0`. Earlier internal development snapshots used higher temporary development numbers; those were not public releases and are not the product's release numbering.

This source tree carries forward the work from those internal snapshots into the first-release version. Earlier source archives and patch files are historical inputs, not separate public releases and must not be overlaid on top of this canonical tree. The current package manifest, app shell, app catalogue, installer metadata and release documentation use `0.1.0`.

This version number does not mean all ten planned apps are complete. Pages, Sheets, Decks and Notes are the only implemented/available editor apps. Database, Forms, Lists, Planner, To Do and Workspace remain planned. Native installers still need to be built and tested on their target operating systems before distribution.
