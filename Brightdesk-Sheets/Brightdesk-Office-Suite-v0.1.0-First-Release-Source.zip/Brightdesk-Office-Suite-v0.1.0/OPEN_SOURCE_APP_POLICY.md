# Brightdesk open-source app module policy

Brightdesk is MIT-licensed. Every Brightdesk application module added to the suite is Brightdesk-owned source code released under the same MIT licence unless a future release explicitly states otherwise.

## Microsoft-inspired scope

Brightdesk may study publicly observable Microsoft 365 product organisation, workflows, feature descriptions, navigation concepts and user-facing behaviour. It does not copy Microsoft's source code, proprietary binaries, artwork, icons, trademarks, private APIs or confidential implementation details.

The current module catalogue covers the publicly documented productivity, design and business app categories selected from Microsoft 365 and Microsoft 365 Business. Teams, Outlook and OneDrive are intentionally excluded by product decision.

## Third-party dependencies

Third-party packages must have compatible open-source licence metadata or licence files. `npm run verify:licenses` remains a required gate before packaging. Brightdesk source remains MIT-licensed and third-party notices remain part of packaged builds.

## Dictionary and language resources

Dictionary resources retain their upstream licence, source, attribution and integrity records. Users may select and install approved catalogue resources, but cannot edit, replace or remove protected dictionary/licence records from inside Brightdesk.

## Individually installable modules

The app catalogue is designed so each module has its own stable ID, module version, Microsoft reference category and independent installation state. Future release artefacts can therefore be distributed as individual Brightdesk app packs instead of forcing every app into every installation.

A production download/update service must only install a module after verifying its Brightdesk release signature/checksum and its module manifest. A real GitHub owner and release signing configuration must be supplied before that network path is enabled.
