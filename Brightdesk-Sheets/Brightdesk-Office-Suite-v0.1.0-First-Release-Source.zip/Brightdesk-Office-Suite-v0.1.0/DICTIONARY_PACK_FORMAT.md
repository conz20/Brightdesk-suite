# Brightdesk spelling dictionary bundle format

A `.bddict` file is a ZIP archive with these files at its top level:

- `manifest.json` — language, source, licence and file names.
- One Hunspell `.aff` file — affix rules.
- One Hunspell `.dic` file — word list.
- The original licence text file (for example, `LICENSE.txt` or `COPYING.txt`).
- Optional `UPSTREAM_README.md` — package README, original source links, author/contributor notes and any additional licence explanations. The built-in catalogue includes this file for all 92 entries.

The `.bddict` extension is used to distinguish dictionary bundles from ordinary ZIP files. The archive must contain no nested folders. The built-in catalogue downloads preserve both the licence document and upstream README; manual bundles may omit the README when no suitable source README exists.

## Example manifest

This example describes the upstream Afrikaans dictionary files in the LibreOffice repository. Before redistributing a dictionary, always re-check the current upstream README and licence text.

```json
{
  "schemaVersion": 1,
  "locale": "af-ZA",
  "name": "Afrikaans (South Africa)",
  "nativeName": "Afrikaans (Suid-Afrika)",
  "authors": "Translate.org.za contributors and upstream word-list authors; see README_af_ZA.txt",
  "affFile": "af_ZA.aff",
  "dicFile": "af_ZA.dic",
  "licenseFile": "README_af_ZA.txt",
  "license": "LGPL-2.1-only",
  "licenseUrl": "https://raw.githubusercontent.com/LibreOffice/dictionaries/master/af_ZA/README_af_ZA.txt",
  "sourceUrl": "https://github.com/LibreOffice/dictionaries/tree/master/af_ZA"
}
```

The upstream Afrikaans README states that the spellchecker is free software and includes the GNU LGPL 2.1 text. Its word lists also identify multiple original contributors and sources, so the README must remain with the dictionary. This example is a format illustration, not a claim that Brightdesk has tested every upstream dictionary file.

## Creating a bundle

1. Download the `.aff` and `.dic` files from the original dictionary project.
2. Download the relevant licence and attribution file. Keep the original text unchanged.
3. Create `manifest.json` using the correct locale, author details, source link, licence identifier and file names.
4. Put the four files together at the top level of a ZIP archive.
5. Rename the archive from `.zip` to `.bddict`.
6. In Brightdesk, open **Languages → Spelling dictionaries → Import dictionary** and select the `.bddict` file.

## Accepted licence identifiers

The importer currently accepts these SPDX-style identifiers (and `OR`/`AND` combinations):

`MIT`, `ISC`, `BSD` (only where that unversioned identifier appears in the upstream collection), `BSD-2-Clause`, `BSD-3-Clause`, `Apache-2.0`, `GPL-2.0`, `GPL-2.0-only`, `GPL-2.0-or-later`, `GPL-3.0`, `GPL-3.0-only`, `GPL-3.0-or-later`, `LGPL-2.1`, `LGPL-2.1-only`, `LGPL-2.1-or-later`, `LGPL-3.0`, `LGPL-3.0-only`, `LGPL-3.0-or-later`, `AGPL-3.0`, `EUPL-1.1`, `LPPL-1.3c`, `SISSL`, `MPL-1.1`, `MPL-2.0`, `CC0-1.0`, `CC-BY-3.0`, `CC-BY-4.0`, `CC-BY-SA-3.0`, `CC-BY-SA-4.0`, `OFL-1.1`, `Unlicense`, `LicenseRef-Public-Domain`, and `LicenseRef-SCOWL`.

This is a technical allow-list, not a legal review. Brightdesk checks the identifier and keeps the licence file; it cannot prove that the manifest's declaration is accurate or that the person creating the bundle has correctly interpreted every upstream copyright notice. Do not import dictionaries labelled proprietary, non-commercial, no-redistribution or with no clear licence. Preserve all upstream attribution, notices and licence terms.

## Engine support

Brightdesk 0.3.7 uses `nspell` 2.1.5. It implements a useful subset of Hunspell in JavaScript, not the entire Hunspell feature set. Dictionary files that rely on unsupported affix, compound, morphology or encoding behaviour may produce incomplete results or fail to load. The current text checker uses Unicode letter tokenisation; languages needing specialised segmentation (for example, Chinese and Japanese) require a different tokenizer and spelling engine.

## Built-in catalogue

Brightdesk 0.3.7 includes a searchable 92-entry catalogue sourced from [wooorm/dictionaries](https://github.com/wooorm/dictionaries), pinned to commit `8cfea406b505e4d7df52d5a19bce525df98c54ab`. Each entry is downloaded from the pinned raw GitHub path for that dictionary's `index.aff`, `index.dic`, and licence text. Two entries (Estonian and Basque) use the matching canonical GNU LGPL-2.1/GPL-2.0 text files bundled unchanged in `src/licenses/`, because their individual package folders do not contain a `license` file. Their licence declarations and official GNU source links remain recorded in the catalogue. Brightdesk creates a local `.bddict` archive and then sends it through the same validation and `nspell` compatibility check used for manual imports. Downloads are performed in the Electron main process from the single fixed `raw.githubusercontent.com` host; redirects are rejected and file sizes/timeouts are capped.

The list is a useful starting catalogue, not a claim that it covers every language in the world. Some languages have no suitable openly licensed Hunspell dictionary; others require tokenizers or morphological engines beyond `nspell`'s subset of Hunspell. A catalogue item is not marked installed unless the source files download, pass manifest/licence checks and load in the current spelling engine. The original per-dictionary licence text and upstream package README are retained locally. The upstream collection is a normalisation/packaging project, not the maintainer of the original language dictionaries; report spelling errors to the original contributors identified in the retained licence/README.


## User-facing protection in Brightdesk 0.3.7

The `.bddict` archive format remains an internal packaging format for validated catalogue installs. User-facing dictionary import and removal have been disabled. The app accepts only manifests that match a locale, source URL, pinned revision, upstream identity, and licence expression from the bundled catalogue. Newly installed dictionary files are written read-only and carry SHA-256 integrity hashes for the affix, word list, licence text, and attribution README. The app checks those hashes before listing or using the dictionary. Existing 0.3.6 catalogue installs are not listed or used until the user chooses Install for that catalogue language. Brightdesk then downloads the pinned upstream resources, compares the existing word list, affix, licence and README with the originals, and only adds integrity hashes if every file matches. Unverified or altered legacy folders are rejected and are never silently overwritten.

Users may install and select a language, but cannot alter the dictionary words, licence, source or attribution in Brightdesk. A person with administrator access to the computer can still modify local application files or replace the application itself; client-side software cannot prevent the owner of a device from changing files outside the app.
