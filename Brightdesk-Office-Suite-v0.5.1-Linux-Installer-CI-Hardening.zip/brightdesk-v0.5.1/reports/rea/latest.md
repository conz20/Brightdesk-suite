# Brightdesk REA Bench report

- **Target:** `/tmp/brightdesk/brightdesk-v051`
- **Generated:** 2026-11-01T11:13:48.281Z
- **Result:** no-static-findings
- **Files inventoried:** 95
- **Total bytes:** 571670

## Scope and limitations

Static source inspection only. No target execution, runtime tracing, binary decompilation, network probing, or proprietary-code extraction.

## App catalogue

- Brightdesk Pages (`pages`) — available
- Brightdesk Sheets (`sheets`) — available
- Brightdesk Decks (`slides`) — available
- Brightdesk Notes (`notes`) — available
- Brightdesk Database (`database`) — planned
- Brightdesk Forms (`forms`) — planned
- Brightdesk Lists (`lists`) — planned
- Brightdesk Planner (`planner`) — planned
- Brightdesk To Do (`todo`) — planned
- Brightdesk Workspace (`loop`) — planned

## Findings

No static findings. This is not a runtime or security certification.

## Inventory by file type

- (none): 6
- .css: 1
- .html: 2
- .js: 38
- .json: 7
- .md: 26
- .ps1: 2
- .sh: 5
- .txt: 5
- .yml: 3

## Evidence inventory

- `.devcontainer/devcontainer.json` — 377 bytes — SHA-256 `130ce507662082c12d525b2ca53588d8926f0c0a6f38ad99099cc526d8a54002`
- `.devcontainer/Dockerfile` — 639 bytes — SHA-256 `a086fd675a8c8e04db56946111d159c38e9c0f87d26d9ee7150ea95d09f39f77`
- `.github/dependabot.yml` — 261 bytes — SHA-256 `fe156952d1952825377de8e48c90563a3ac19bb95a6e0ced8a2f498a0f20fdf6`
- `.github/workflows/build-release.yml` — 8651 bytes — SHA-256 `faacff2828eb54eefaf9ee8f68a67480d9d6db054a2ba89b2851030e4a4f79bf`
- `.github/workflows/security-audit.yml` — 644 bytes — SHA-256 `bfe16fa51de1f08c09e56272a409e5429d2098a33f1c713d4e3d45020cfda5dd`
- `.gitignore` — 60 bytes — SHA-256 `b302c5f3caa3a08da819745e62a77ac0bafd7f19a86c9805846d1f805098d71c`
- `.node-version` — 8 bytes — SHA-256 `9185b9f67843cabfa8054f65ce47ce0b52036b0bfe07ae5a6b834d97cc127140`
- `.npmrc` — 42 bytes — SHA-256 `280f9216da91ef0ae6d4b783762cc5f2b6bf041323bcf3f6f3972c9ffd462dcc`
- `.nvmrc` — 8 bytes — SHA-256 `9185b9f67843cabfa8054f65ce47ce0b52036b0bfe07ae5a6b834d97cc127140`
- `AGENTS.md` — 12805 bytes — SHA-256 `959eced9e64ce5e94c1452f2bb4c08bf8723befb5c72b1e8fe085e87932090d3`
- `APP_IMPLEMENTATION_MATRIX.md` — 2504 bytes — SHA-256 `b3978bb4e6334f140e0535f5a0d3caa90997d53553c546ba27f3e9c59c86c81c`
- `ARCHITECTURE.md` — 4364 bytes — SHA-256 `fc1c405fe0adbc651586f4901c893dc1e815f096cbc71167ef04ac0882f041e1`
- `BRIGHTDESK_REA_BENCH.md` — 2494 bytes — SHA-256 `a1b82dcd4e0a45a40805d5cf5462ed9ac9b118c861a9d9a206e499420b2975cf`
- `BUILD_STATUS.md` — 21629 bytes — SHA-256 `9fa48d897b7477c2510a83690a3815469eb2915b03ceb45d2992726f9552fa09`
- `CHANGELOG.md` — 21062 bytes — SHA-256 `2d9ee5ec944ff517f95efb2a045e9728fbb83daab00d68f636e6f9f1e27bd28b`
- `DEPENDENCY_SETUP.md` — 2249 bytes — SHA-256 `0a00a470761f01227f6f419a60cd2137ebdf4547c8c79070d48759c1ea84cfda`
- `DICTIONARY_PACK_FORMAT.md` — 7077 bytes — SHA-256 `b0e2f2c9330fc40dcf20985edcc7a6dc4d3b6bc1b44872ad516653292838f5b0`
- `electron-builder.app.config.js` — 1201 bytes — SHA-256 `47c9967ca141b822b7cf53814ccc756dc272d569cf31308e8f7967a33d45f3a2`
- `installer/install-linux.sh` — 1115 bytes — SHA-256 `522027c87e2f7fed341d812721b006b3b712c74969ef7688d0a71534188b07f8`
- `installer/mac-conclusion.txt` — 215 bytes — SHA-256 `c86bb6037292c00bff1b15d38040712c3a87aa819e3897b7a38f71106d1fd0fe`
- `installer/mac-welcome.txt` — 243 bytes — SHA-256 `e815901b642efc94db6e1740a2030a309da0300c2f29fbec3d011de7438fd140`
- `LANGUAGE_AND_DICTIONARY_PROTECTION.md` — 2392 bytes — SHA-256 `b7303a026577aab58c08b3f5b68e95a41bd6dfeb51b752d2e7e4499d543bf530`
- `LANGUAGE_PACK_FORMAT.md` — 1606 bytes — SHA-256 `fa7e05c564aa02bac225df7cb8b6d9c993bf4f4b741d66dfc1782e9dbbe38db8`
- `LICENSE` — 821 bytes — SHA-256 `8fa9335ec671084af1a50768fcb78e0b3e2d89e5e3a8ee9d5afcf727f3b63478`
- `MICROSOFT_365_REVERSE_ENGINEERING_SCOPE.md` — 1583 bytes — SHA-256 `092f2c3feae49c7f56af6e4be6ea8eb74c2c20372119b785d8e524d7b94d471d`
- `NODE24_DEVELOPMENT_ENVIRONMENT.md` — 3636 bytes — SHA-256 `ea5c5999bc0d19228ae0670dca8133efc0fa8cf99af35bda4dcf69d101e0c14a`
- `NODE24_PROVISIONING_REPORT.md` — 6028 bytes — SHA-256 `e56a66eb8b3ae9aa4f64b062d09c22b843f43eb1f847874e80130acee2f08e64`
- `NODE24_SETUP_IMPLEMENTATION_REPORT.md` — 3409 bytes — SHA-256 `53727e138e9ad6b8daa9f9e47bee9444584aa82b14fd97068dfb6c1d42a202bc`
- `OPEN_SOURCE_APP_POLICY.md` — 1979 bytes — SHA-256 `d5815fa6500b69d25e8a78d0cc84a8996b906c3d0d910a14d5cb27c7685d129b`
- `package.json` — 4274 bytes — SHA-256 `ea8805ab21bc710e7f0a1432bbc3a8334bd2d39e93d37d41223b5fb0c4553a4b`
- `PRODUCT_PLAN.md` — 4895 bytes — SHA-256 `8403ea5e06ea6db1f029a3c6d1eaece58f3aa32747e6d81ed864317a2bbec44f`
- `PRODUCT_SCOPE_LOCK.md` — 2527 bytes — SHA-256 `b2c01a0730a5aba386f01b02c9baada30a58691ec1121d143ec87409dfdd4147`
- `PROJECT_MEMORY.md` — 10782 bytes — SHA-256 `fe4521f623840f65517affb592e91f21b7d9fbe74558c529119b62f3450fc82d`
- `README.md` — 18120 bytes — SHA-256 `25c345d817f0fd15ff4a4462950d9a0dcd97885567c4671d5d5be81bafb6018d`
- `RELEASE_READINESS.md` — 7330 bytes — SHA-256 `89ac17b43710dcdbfb3f5f984d49d0961387bc3191c53cb6addfe148506e0c01`
- `RELEASE_SIGNING_SETUP.md` — 1843 bytes — SHA-256 `c198f0de2a12ced804d3b8c6ff56ea167a5efc3b84f8dbe56ef06029082e6b66`
- `REVERSE_ENGINEERING_SOURCE_REVIEW.md` — 15768 bytes — SHA-256 `ac0610b967a6a6deb7b41be97fe5cb194cdc2987890ca735c310d4d62c27af86`
- `scripts/activate-node24.sh` — 696 bytes — SHA-256 `0e21010b8e6799c08c33aff75d7800c37182b32a71d96e5693fb5d9550802eaf`
- `scripts/brightdesk-rea.js` — 8288 bytes — SHA-256 `126cac3a8e21796a9ef9db0e65bc90e09abf5fbefa46e43b58b15db3e0e4e616`
- `scripts/build-app.js` — 1002 bytes — SHA-256 `9bf2a1355896043281a139a796c78dca2b28d49b733632e13f163c697bacbf1a`
- `scripts/build-apps.js` — 718 bytes — SHA-256 `09a240316544af30e8753849b3f29f3dbe424a33d2b1112cc1399587c71dfa40`
- `scripts/check-node24.js` — 415 bytes — SHA-256 `74c7f31b71ebbdd68b17ddaceff47389d2380308c4b7761e6c6422dbb09dad0e`
- `scripts/fix-app-js.js` — 1901 bytes — SHA-256 `7f4b7ff79941935c5dd0d53a42ba34da52eab4702859b563bd267c8e83682bc7`
- `scripts/install-node24.ps1` — 3433 bytes — SHA-256 `41f7ef2c9bc929ce581dea610dd8bd0ad4093280555ab19d136faed10f448a81`
- `scripts/install-node24.sh` — 3551 bytes — SHA-256 `574ea544ea983d76533105c63688bf24acfe8369b4f99cbf9f4ef7c17938b215`
- `scripts/prepare-release-assets.js` — 1124 bytes — SHA-256 `17393ebaf69907654617b6342eea4e20754752b819dfd2e4ccf40fed68464623`
- `scripts/release-preflight.js` — 6654 bytes — SHA-256 `5f0421f4fe3440c1d84e44bfa34c6456324ba694dfcaefa5f7984fb35c9eceac`
- `scripts/setup/bootstrap-dev.js` — 1793 bytes — SHA-256 `52c2e9964c24dd810c46430a546c3d2a92e606de336c10978bd6ba1de9df56b8`
- `scripts/setup/install-dependencies.ps1` — 839 bytes — SHA-256 `908bd0bf5fd4a3ced43a97169085df5d861dd147960ff5c17384de9251eb0c28`
- `scripts/setup/install-dependencies.sh` — 1231 bytes — SHA-256 `61bba68a079a8e8c0a1d8c786ee929cfbc3b68df4f7588e791aa7a83923907cd`
- `scripts/use-node24.sh` — 658 bytes — SHA-256 `482d4a5d5ecd0034b97e0a80e99abbf772153f5be7f116b924f549a3d066fea2`
- `scripts/verify-licenses.js` — 6462 bytes — SHA-256 `2d5d09bc77058e9b0b310da64bb9b71e3c8f556eb355e331d6e5241759c6a753`
- `scripts/verify-lockfile.js` — 2109 bytes — SHA-256 `ab58958f1fb9ef992768bedcd20a9969d6f0826686680d87a12c8c531f4576b6`
- `scripts/verify-release-artifacts.js` — 3144 bytes — SHA-256 `3d823ba727f31170afe7b6e189e4aa389eaadb91af36fb71f3a48bd0be2ea7c9`
- `SOURCE_HISTORY.md` — 1316 bytes — SHA-256 `9e8297dccd0869faf509821781fe7824ee9b412d698d5c5a97194ea39d99031d`
- `src/app-catalog.js` — 3411 bytes — SHA-256 `3726756d6fc1746434741edf23f261ded944ec476bc981eddd32613a65708d31`
- `src/app.js` — 55930 bytes — SHA-256 `92579fce58bb6fe165d119568bc53f5e929ca052c9f0201ba98ee0487c7fb075`
- `src/dictionary-catalog.json` — 30745 bytes — SHA-256 `919ece2c232e04525b1c6e9222a4fb202574292b165093cf886e11d37f4db4c2`
- `src/dictionary-service.js` — 31632 bytes — SHA-256 `481e8dc54e658fff5f0b690c4384caa21c5d22a96a716b8fd873ca9f94d6b432`
- `src/file-service.js` — 12964 bytes — SHA-256 `e139b109bd8370d2a68773f91a36f080afa421ce2ddb18e6c2b3b68b9d7e7f46`
- `src/formula.js` — 4334 bytes — SHA-256 `b8963e977972c8516e81fa281838b0eed88fcd7045d73c777895ab73bb721a42`
- `src/i18n.js` — 8187 bytes — SHA-256 `73ad80145aee22cf196cee8785680a21617db5943f14ccd087c04429504098b7`
- `src/index.html` — 9652 bytes — SHA-256 `d3bfa7467d85edf5c84f029bb124fd0bd1f6f6e9573ac2d58306e92ddec8b312`
- `src/language-service.js` — 5642 bytes — SHA-256 `e794695204d7d639e1b2dc718477c0b9b88a717c6f8294beb3adb9abfa02b6a6`
- `src/languages/de-DE.json` — 8465 bytes — SHA-256 `104386c2626e6ae3fd0e760b73f565759512641e337da8c4d55e8a927c2f354e`
- `src/languages/en-AU.json` — 7859 bytes — SHA-256 `12bf43d4b1e35a1da8241354645691af8620b798a2b615be4c7be4e22817596d`
- `src/languages/es-ES.json` — 8504 bytes — SHA-256 `5309ebebaba6fa8fe275b10848ed190c72c6c2ca07b2fadb05b6760b30ea8881`
- `src/languages/fr-FR.json` — 8712 bytes — SHA-256 `267f3a8ef0c10424eb6cb7e12297a592deaaee85b6f42780f5c7acb2463da05d`
- `src/licenses/GPL-2.0.txt` — 17984 bytes — SHA-256 `edaef632cbb643e4e7a221717a6c441a4c1a7c918e6e4d56debc3d8739b233f6`
- `src/licenses/LGPL-2.1.txt` — 26419 bytes — SHA-256 `20e50fe7aae3e56378ebf0417d9de904f55a0e61e4df315333e632a4d3555d95`
- `src/licenses/README.md` — 711 bytes — SHA-256 `28f74ebc067dcf4dbd44905f597ff0a71b37d359cfe5b84fe9f091b435db32ee`
- `src/main.js` — 18759 bytes — SHA-256 `380648772292ede97b33c3bf0c2c281461fbba2f228acb65b1c0892f2a676a20`
- `src/page-layout.js` — 1806 bytes — SHA-256 `9a4b1c15058bb796cb9fd9b5a44e65d331f5a3204aeefcb3244134668e37f3c0`
- `src/preload.js` — 1738 bytes — SHA-256 `de6e056a117f9399c05ffe07072b3a5a8306ad023ad001b39b38b0d692d36e80`
- `src/styles.css` — 17209 bytes — SHA-256 `9fb9467b78c37435feaac13476178c07410629063f9efffba9aa1a4f50497705`
- `src/terms-preload.js` — 291 bytes — SHA-256 `d8dad2f08e8ac081fef75e7525efb959fa468829d9cae0dd01cad616ce0a95a3`
- `src/terms.html` — 1844 bytes — SHA-256 `db2a9a590ee8943a5541767e03a115923ad6c1f51e10784df2075bbf3741f475`
- `src/terms.js` — 900 bytes — SHA-256 `e0dc3b9c271ab2a45f36ce6798cd6bd1ba248ad1fc116ffeb71b0c723bb33c8a`
- `TERMS_AND_CONDITIONS.txt` — 3344 bytes — SHA-256 `0afd25c784b7479684fe93a2cc4e02d2564c363f1678532b63a83f873b76b05d`
- `tests/app-catalog.test.js` — 7355 bytes — SHA-256 `ef6b1acdc2ecc41fd48a75498672ac21b6c08acb502e2f3b1c9c667217da37d4`
- `tests/dictionary-service-live.test.js` — 2640 bytes — SHA-256 `da7b8b1a0a69c55986f0b8d116c69d3227db10aa3979e6d5fd2b2db025681db6`
- `tests/dictionary-service.test.js` — 11853 bytes — SHA-256 `7820f66993958f2d76c1ba2b735e0fe0154a078bf9fcdd7e0ca6f392ee444243`
- `tests/file-service.test.js` — 4468 bytes — SHA-256 `88d1b3aada1eba6755566bad68ae9d150356453af0ae425ebcf154051c20b54c`
- `tests/formula.test.js` — 1257 bytes — SHA-256 `115eabab1d750f98c0f3c2fdcaed6d216edde6b8373422644567eefa816676e6`
- `tests/installer-agreement.test.js` — 3557 bytes — SHA-256 `c8c5eaa788b06c3d9262c3feb9354d455a0c4b7a6ed206d3b4fc0ba7120b7987`
- `tests/language-service.test.js` — 1934 bytes — SHA-256 `54bed2db8efcfd9c766d7e8057301994be604fbcf88d9e52b599a276560ca236`
- `tests/license-verification.test.js` — 2707 bytes — SHA-256 `43a2dbb89be10927230590131176963ae5fa1ea7d21e312e8ebf9fee7af7ea42`
- `tests/node-runtime-setup.test.js` — 3420 bytes — SHA-256 `5e8b30eeecc37388dc5bb40bfe8ac25adabd4c5cf232ec136f6e43ee8b53c4c4`
- `tests/page-layout.test.js` — 1328 bytes — SHA-256 `2df93b49c646136a35835345dba02f114389983f9acd37c14c4ad73154873618`
- `tests/rea-bench.test.js` — 1177 bytes — SHA-256 `d65859b5ec85f2cef4bab2f58df2e7097cb445cbb8e8300d7bd0b5011b0bdd8d`
- `tests/release-readiness.test.js` — 4975 bytes — SHA-256 `b4d7f637d6b01a3b274cf453409b7ac1ff35fcce980892a3ba1f976619379cb9`
- `tests/release-workflows.test.js` — 5971 bytes — SHA-256 `69c013a2d0df9183b1f12ab6ad96e81b647bae8902355655bef9cc05533dfb83`
- `tests/resource-protection.test.js` — 3278 bytes — SHA-256 `0ffe129260f99ae78adc98d1155ad34cccacb59718342cee3ba2491f1ebfb59e`
- `THIRD_PARTY_NOTICES.md` — 1070 bytes — SHA-256 `a460c15a7136f9be17d0dcbdd3c74c8602f9afbbcef9cbeb43b28ca8cebf387a`
- `WORLD_LANGUAGE_DICTIONARIES.md` — 7663 bytes — SHA-256 `dd35be9371d548f851da6f06737ccbd76382a89c86570331663e117d07b25c51`
