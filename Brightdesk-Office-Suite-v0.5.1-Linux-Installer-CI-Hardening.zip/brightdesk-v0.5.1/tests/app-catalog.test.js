'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../src/app-catalog');

test('app catalogue starts with the four implemented Brightdesk office apps', () => {
  assert.deepEqual(catalog.slice(0, 4).map(app => app.id), ['pages', 'sheets', 'slides', 'notes']);
  assert.deepEqual(catalog.slice(0, 4).map(app => app.name), ['Brightdesk Pages', 'Brightdesk Sheets', 'Brightdesk Decks', 'Brightdesk Notes']);
  assert.equal(catalog.length, 10);
});

test('every app has a unique id, release version and user-facing details', () => {
  const ids = catalog.map(app => app.id);
  assert.equal(new Set(ids).size, ids.length);
  for (const app of catalog) {
    assert.match(app.moduleVersion, /^\d+\.\d+\.\d+$/);
    assert.ok(app.name && app.subtitle && app.description && app.icon);
  }
});

test('Brightdesk keeps its own identity and does not claim Microsoft affiliation', () => {
  const fs = require('node:fs');
  const readme = fs.readFileSync(require('node:path').join(__dirname, '..', 'README.md'), 'utf8');
  assert.match(readme, /independent/i);
  assert.match(readme, /not affiliated with Microsoft/i);
});

test('automatic updates stay clearly disabled until a real GitHub owner is configured', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  assert.deepEqual(pkg.build.publish, []);
  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  assert.match(main, /Automatic updates will be available after the Brightdesk GitHub release repository is configured/);
});

test('the main app rail keeps the four core apps as the permanent base rail', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const html = fs.readFileSync(path.join(__dirname, '..', 'src', 'index.html'), 'utf8');
  for (const name of ['Brightdesk Pages', 'Brightdesk Sheets', 'Brightdesk Decks', 'Brightdesk Notes']) assert.match(html, new RegExp(`<b>${name}</b>`));
  for (const oldName of ['<b>Word</b>', '<b>Excel</b>', '<b>PowerPoint</b>', '<b>OneNote</b>']) assert.doesNotMatch(html, new RegExp(oldName));
});

test('catalog is hard-limited to the ten approved Brightdesk apps', () => {
  assert.deepEqual(catalog.map(item => item.id), ['pages','sheets','slides','notes','database','forms','lists','planner','todo','loop']);
  assert.deepEqual(catalog.map(item => item.name), ['Brightdesk Pages','Brightdesk Sheets','Brightdesk Decks','Brightdesk Notes','Brightdesk Database','Brightdesk Forms','Brightdesk Lists','Brightdesk Planner','Brightdesk To Do','Brightdesk Workspace']);
  const forbidden = ['teams','outlook','onedrive','diagrams','stories','video','whiteboard','bookings','sharepoint','powerapps','powerautomate','analytics','projects','viva','places','copilot'];
  for (const id of forbidden) assert.equal(catalog.some(item => item.id === id), false, `forbidden app present: ${id}`);
});

test('the canonical product scope lock matches the executable catalogue', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const scope = fs.readFileSync(path.join(__dirname, '..', 'PRODUCT_SCOPE_LOCK.md'), 'utf8');
  for (const name of catalog.map(item => item.name)) assert.ok(scope.includes(name), `scope lock missing ${name}`);
  for (const excluded of ['Outlook', 'OneDrive', 'Teams']) assert.match(scope, new RegExp(`\\b${excluded}\\b`));
  assert.match(scope, /scope can change only when the user explicitly instructs/i);
});

test('all catalogue modules have independent Brightdesk metadata', () => {
  for (const item of catalog) {
    assert.ok(item.id && item.name && item.description && item.moduleVersion);
    assert.equal(typeof item.microsoftReference, 'string');
  }
});

test('only the four implemented editor apps are marked installable', () => {
  const available = catalog.filter(item => item.availability === 'available').map(item => item.id);
  assert.deepEqual(available, ['pages', 'sheets', 'slides', 'notes']);
  for (const item of catalog.filter(item => item.availability !== 'available')) assert.equal(item.availability, 'planned');
});

test('standalone app packaging has independent product IDs and all three platform targets', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const root = path.join(__dirname, '..');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  for (const app of ['pages', 'sheets', 'decks', 'notes']) {
    for (const platform of ['win', 'mac', 'linux']) assert.ok(pkg.scripts[`dist:${app}:${platform}`]);
  }
  const builder = fs.readFileSync(path.join(root, 'electron-builder.app.config.js'), 'utf8');
  assert.match(builder, /org\.brightdesk\.\$\{appId\}/);
  assert.match(builder, /brightdeskAppId: appId/);
  assert.match(builder, /extraMetadata: \{ brightdeskAppId: appId, productName:/);
  const configPath = path.join(root, 'electron-builder.app.config.js');
  const previousAppId = process.env.BRIGHTDESK_APP_ID;
  const products = [];
  try {
    for (const [id, name] of [['pages','Pages'],['sheets','Sheets'],['slides','Decks'],['notes','Notes']]) {
      process.env.BRIGHTDESK_APP_ID = id;
      delete require.cache[require.resolve(configPath)];
      const config = require(configPath);
      assert.equal(config.appId, `org.brightdesk.${id}`);
      assert.equal(config.extraMetadata.brightdeskAppId, id);
      assert.equal(config.extraMetadata.productName, `Brightdesk ${name}`);
      assert.ok(config.win.artifactName.includes(name));
      assert.equal(config.directories.output, `release/apps/${id}`);
      assert.ok(config.mac.target.includes('pkg'), `${name} mac build must include pkg for installer licence`);
      assert.ok(config.mac.target.includes('dmg'), `${name} mac build must include dmg`);
      assert.ok(config.mac.target.includes('zip'), `${name} mac build must include zip`);
      products.push(config.productName);
    }
  } finally {
    if (previousAppId === undefined) delete process.env.BRIGHTDESK_APP_ID;
    else process.env.BRIGHTDESK_APP_ID = previousAppId;
    delete require.cache[require.resolve(configPath)];
  }
  assert.equal(new Set(products).size, 4);
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  assert.match(main, /--brightdesk-app=/);
  const preload = fs.readFileSync(path.join(root, 'src', 'preload.js'), 'utf8');
  assert.match(preload, /launchAppId/);
  const renderer = fs.readFileSync(path.join(root, 'src', 'app.js'), 'utf8');
  assert.match(renderer, /launchAppId && app !== launchAppId/);
  assert.match(renderer, /This Brightdesk .* installation opens/);
});

test('the standalone build scripts reject unknown app and platform identifiers', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const root = path.join(__dirname, '..');
  const build = fs.readFileSync(path.join(root, 'scripts', 'build-app.js'), 'utf8');
  assert.match(build, /Usage: node scripts\/build-app\.js/);
  assert.match(build, /'pkg'/);
  assert.match(build, /new Set\(\['pages', 'sheets', 'slides', 'notes'\]\)/);
  const config = fs.readFileSync(path.join(root, 'electron-builder.app.config.js'), 'utf8');
  assert.match(config, /Set BRIGHTDESK_APP_ID/);
});
