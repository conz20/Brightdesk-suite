## 0.5.1 — Exact Node.js 24.22.2 LTS and CI lock preparation (2026-11-01)

- Pinned Brightdesk tooling, Dev Container and native CI runners to Node.js 24.22.2 LTS.
- Added strict runtime verification and dependency-lockfile validation commands.
- Updated CI to generate one real dependency lock on a Node.js 24.22.2 runner and share it across Windows, macOS and Linux builds; release metadata retains that exact lockfile.
- Updated the scheduled dependency audit to generate and verify the lock before running `npm ci` and `npm audit`.
- Made legal document and checksum filenames platform-specific so Windows, macOS and Linux assets cannot collide in a combined GitHub Release.
- The current isolated host cannot download Node.js or npm packages, and no connected GitHub repository is available to run CI. No installer build is claimed.

## 0.5.1 — exact Node.js 24.22.2 provisioning and CI preparation (2026-11-01)

- Standardised `.nvmrc`, `.node-version`, `package.json`, npm engine enforcement, the Dev Container and GitHub Actions on Node.js **24.22.2 LTS**.
- Added a real lockfile preparation and verification path. The three native CI jobs now share one lockfile generated on a network-connected Node.js 24.22.2 runner; no fabricated lockfile or integrity hashes are used.
- Corrected platform-specific release legal-document and checksum naming to avoid cross-platform asset collisions.
- Found a bundled Node.js 24.11.1 executable and used it for an additional compatibility run: 68 tests passed, 0 failed, 1 network-only test skipped. This is not an exact 24.22.2 test.
- Added `NODE24_PROVISIONING_REPORT.md` with the exact provisioning attempts, compatibility checks and remaining release blockers. Provisioning Node.js 24.22.2 and downloading dependencies remain blocked by DNS/network limits in this workbench. The connected GitHub account has no accessible Brightdesk repository, so GitHub Actions cannot yet be run. No installers are claimed as built.

# Changelog

## 0.5.1 — Node.js 24 development environment (2026-11-01)

- Standardised the project on Node.js 24.x and made npm enforce the required engine major.
- Added a Node.js 24 Dev Container with Linux/Electron packaging prerequisites.
- Added nvm setup and runtime-check scripts plus setup documentation.
- The current host could not download Node.js 24 because `nodejs.org` DNS resolution failed; the container definition is configured but has not yet been built. No installers were built in this update.

## Unreleased — fixed Brightdesk product scope and names

- Removed an unused module defaults object, a duplicate HTML-escaping helper, and an unused toolbar helper from `src/app.js`; no user-facing behaviour was changed.

- Added the ArtCraft-inspired app-family experience direction: original Brightdesk design, shared App Centre and independent app packaging without expanding the ten-app scope.
- Added a durable REA and coding-assistance workflow to `AGENTS.md`, including clear boundaries between static checks and actual external REA analysis.
- Expanded validation to 52 passing tests and recorded a 63-file Brightdesk REA Bench static inspection.
- Hard-limited the catalogue to exactly ten approved applications: Brightdesk Pages, Sheets, Decks, Notes, Database, Forms, Lists, Planner, To Do and Workspace.
- Replaced user-facing Microsoft product names with original Brightdesk application names.
- Removed all out-of-scope creative, business and optional AI catalogue entries.
- Kept Outlook, OneDrive and Teams permanently excluded.
- Updated the product plan, implementation matrix, reverse-engineering scope, App Centre catalogue tests and standalone installer naming.
- Kept only Pages, Sheets, Decks and Notes installable until the other six apps are actually implemented and tested.

# Changelog

## 0.5.1 — consolidated development snapshot

- Consolidated the latest saved source tree with the previous 0.4.1 and 0.5.0 project work.
- Corrected the package, shell and implemented core-module version labels to `0.5.1`.
- Kept Outlook, OneDrive and Teams excluded.
- Retained the 48-test baseline and added a clear release-readiness record.
- This is a development source snapshot only; it is not an installer release.

## 0.5.0 — project-file validation and implementation handoff (working update)

- Added strict validation for Brightdesk `.bdesk` project files, including known app IDs, excluded app IDs, document object shapes, spreadsheet cell values, presentation slide indexes and bounded content sizes.
- Added regression tests for malformed project files, unsupported app modules and oversized/invalid document data.
- Added a full product plan, target architecture, app-by-app definition of done and contributor instructions so future changes are measured against actual workflows rather than placeholder screens.
- Updated build status to distinguish passing unit tests from dependency licence checks, native installer builds and real app feature completion.
- Validation: 48 unit tests pass. Dependency licence verification and installer builds remain blocked because dependencies could not be installed in this environment.

## 0.5.0 — standalone downloads for the four implemented apps

- Added separate Windows NSIS, macOS DMG/ZIP and Linux AppImage/DEB build targets for Word, Excel, PowerPoint and OneNote, alongside the full Brightdesk suite installer.
- Each standalone installer has its own product name, application ID, install profile and user-data location, and opens directly into its matching editor.
- The standalone launch mode prevents switching to another app and rejects imports for a different app type.
- The App Centre now distinguishes implemented, installable apps from planned catalogue entries; unfinished entries are labelled In development and cannot be installed as if they were complete.
- Expanded the cross-platform release workflow to build and upload the suite plus all four standalone app installers.
- REA tool execution and native installer smoke tests remain release gates where the required connected tools/runners are unavailable.


## 0.4.1 — expanded Microsoft 365-inspired open-source app catalogue

- Expanded Brightdesk from the original four work areas into an independently selectable app catalogue based on publicly documented Microsoft 365 and Microsoft 365 Business productivity categories.
- Added Brightdesk modules for Database, Forms, Lists, Planner, To Do, Workspace, Diagrams, Stories, Video, Whiteboard, Bookings, Team Sites, App Builder, Automation, Analytics, Projects, Viva, Places and an optional AI Assistant.
- Explicitly excluded Teams, Outlook and OneDrive by product decision.
- Added dynamic app navigation so installed modules appear in the Brightdesk workspace without changing the protected core shell.
- Added a public-product reverse-engineering scope document and open-source module licensing policy.
- Preserved Brightdesk MIT licensing, third-party licence verification, protected dictionary/licence resources and the no-Microsoft-affiliation notice.
- Added regression tests for the expanded catalogue and excluded products.


## 0.3.8 — integrated installer and first-run setup

- Included the supplied Dependabot, desktop build/release and scheduled dependency-audit workflows, with working release-write permissions.
- Kept dependency installation compatible with the current repository by using `npm install` in CI until a complete npm lockfile can be generated and committed; `npm ci` is not used without that lockfile.
- Windows NSIS setup displays the Brightdesk MIT licence and provides a normal installer flow with desktop and Start Menu shortcuts.
- Fresh installations automatically activate all four bundled apps (Pages, Sheets, Decks and Notes), so users do not need to complete a second app-selection wizard after installing Brightdesk.
- Added regression tests for first-run app activation, Windows installer licence configuration and release workflow permissions.
- Confirmed all 37 unit tests pass. A full installer build still requires Node.js 24, dependency installation and platform build runners.

## 0.3.7 — protected language and dictionary resources

- Removed end-user import and removal controls for spelling dictionaries and language packs.
- Removed the corresponding preload API methods and IPC handlers.
- Catalogue dictionaries can only be installed from the built-in, pinned catalogue; existing locale folders cannot be overwritten.
- Catalogue identity, locale, upstream revision, source URL, licence expression and licence source are checked against the bundled catalogue before a dictionary is listed or used.
- New dictionary installs store SHA-256 integrity hashes for the affix file, word list, licence text and upstream attribution README. The app verifies these before use.
- Dictionary files, licence text, manifests, attribution records and language-pack files are made read-only on disk where the platform supports it.
- The language manager now allows users to install approved catalogue packs and select their display/proofing language, without editing or replacing the language resources.
- Selecting a proofing language automatically selects a matching installed dictionary by exact locale or base language; it clears the selection when no matching dictionary is installed.
- Added tests for import/removal denial, catalogue-only installation, no-overwrite behaviour and protected resource integrity.
- Confirmed all 34 unit tests pass and JavaScript syntax checks pass.


## 0.3.6 — worldwide dictionary catalogue and source architecture review

- Added a searchable catalogue of 92 Hunspell dictionary variants from the `wooorm/dictionaries` collection, including regional variants, upstream licence declarations, and the source package README for attribution.
- Pinned catalogue downloads to a specific upstream Git commit so the same catalogue entry resolves to the same upstream files until Brightdesk deliberately updates the pin.
- Added main-process-only HTTPS downloads from the pinned `raw.githubusercontent.com` dictionary source, with redirects rejected, timeouts, size limits and locale IDs restricted to the built-in catalogue. Two canonical GNU licence texts are bundled unchanged for catalogue entries without per-package licence files.
- Added one-click dictionary installation while retaining the original upstream licence text and source links in each installed dictionary.
- Expanded the licence identifier allow-list to cover the catalogue’s legacy GPL/LGPL expressions, AGPL, EUPL, LPPL and SISSL labels. Unknown or proprietary terms remain rejected.
- Added search by language, region, locale code and licence, with paged display of results so the full catalogue does not flood the screen.
- Kept manual `.bddict` import for additional dictionaries that meet the licence and format checks.
- Added a complete 92-variant catalogue reference and a static Electron source architecture/reverse-engineering handoff report.
- Kept the supported Electron 45 release line and current electron-builder 26 configuration; removed no existing office-suite functionality.
- Added catalogue, licence, IPC and installation-guard regression tests.


## 0.3.5 — open-source spelling dictionary centre

- Added a separate spelling-dictionary library alongside the existing interface-language packs.
- Added the `.bddict` bundle format for a Hunspell `.aff` file, `.dic` word list, manifest, original licence text and source attribution.
- Added validation for language tags, HTTPS source/licence links, archive contents, file sizes and a list of recognised free/open-source licence identifiers.
- Added offline dictionary installation, removal, persistence and spelling checks for Pages, Sheets, Decks and Notes.
- Added the MIT-licensed `nspell` JavaScript engine. It supports a useful subset of Hunspell, but is not a complete replacement for every Hunspell feature or every writing-system tokenizer.
- Existing operating-system spell checking and the original four interface-language packs remain available.

## 0.3.4 — open-source licence verification

- Confirmed Brightdesk's own source remains MIT-licensed, with no product activation, serial number or licence-server requirement.
- Added an offline dependency licence audit that runs after npm dependency installation and before desktop packaging.
- Generates `THIRD_PARTY_NOTICES.md` with installed package versions, declared licence terms and available licence texts.
- Flags dependencies explicitly marked unlicensed/proprietary or missing both licence metadata and a licence file.
- Includes Brightdesk's MIT licence and third-party notices in packaged builds; Windows NSIS shows the licence during installation.
- Added automated tests for valid, unlicensed and incomplete dependency licence metadata.

## 0.3.3 — stability, import and workspace fixes

- Re-applied and verified the additional stability fixes included in the 0.3.1 text source supplied for this project, so they are retained in the current language-pack release line.
- Pages sanitising now preserves tables, horizontal rules and safe numeric `colspan` / `rowspan` values during switching and `.bdesk` round-trips.
- Notes focus mode now hides the document header and ribbon using the workspace-level focus state.
- Sheets now refreshes calculated values in place after edits, preserving the active cell and Enter-to-advance behaviour; formula-bar edits no longer rebuild the entire grid.
- `COUNT` and `AVERAGE` ignore blank cells in ranges.
- App Centre installation status now appears beside the Install / Remove action in each app card footer.
- TSV imports use a dedicated tab-aware quoted-field parser.
- Export, project-save and PDF dialogs append the default file extension when it is missing.
- The displayed version is read from Electron's actual packaged app version rather than relying on a hard-coded label.
- Opening a `.bdesk` workspace switches back to the workspace view and ensures an app is installed and active.
- Added regression tests for TSV parsing, extension handling and blank-cell formula behaviour.
- Confirmed all 17 unit tests pass; JavaScript syntax checks pass.

## 0.3.2 — installable language packs

- Added a Language Centre with separate display-language and proofing-language settings.
- Added installable English (Australia), French (France), German (Germany) and Spanish (Spain) interface packs.
- Language packs are copied to Brightdesk's per-user application data folder, so they remain installed across suite updates and separate from project documents.
- Added import support for validated `.bdlang` / JSON language-pack files, including locale-code, translation-value and file-size checks.
- Added proofing-language integration with Electron's platform spell checker. Windows and Linux use supported Hunspell dictionaries; macOS uses macOS spelling settings.
- Added tests for language catalogue metadata, bundled pack contents and invalid language-pack rejection.

## 0.3.1 — file-service test isolation fix

- Fixed the test-suite startup failure caused by eagerly loading `mammoth` and other Office-format libraries when the file service was imported.
- DOCX, XLSX and PPTX conversion libraries now load only when the matching file format is used.
- Kept all Office-format libraries declared as application dependencies; normal app installs still need `npm install`.
- Confirmed all 10 unit tests pass in the dependency-free source-check environment.

## 0.3.0 — App Centre and ribbon workspace

- Added an initial app-selection screen so people can choose Pages, Sheets, Decks and Notes.
- Added an App Centre for installing and removing apps from the workspace while retaining local documents.
- Added an Office-inspired ribbon layout with app-specific Home, Insert, Layout, Review, View, Formulas, Data, Design and Slide Show tabs where applicable.
- Added basic ribbon actions for document tables/alignment, spreadsheet formulas and sorting, slide presets/themes, note helpers and zoom/focus controls.
- Added an independent module version field for each app.
- Added automatic update downloads for published suite releases, with periodic checks on startup, window focus and every six hours.
- A Brightdesk release updates the shell and any changed app modules together, avoiding mismatched versions in this bundled-module build.

## 0.5.1 — release pipeline hardening

- Added a fail-closed release preflight for Node 24+, a committed npm lockfile, installed build dependencies, native build host and approved app catalogue.
- Added platform installer-format verification and SHA-256 checksum generation.
- Added regression tests for release preflight and artifact verification.
- Changed CI to use `npm ci`, validate installers after native builds, and build only the suite package until individual apps are complete.


## 0.5.1 — Installer agreement and release hardening (2026-11-01)

- Added free/open-source Terms and Conditions with no activation code, product key, subscription or account requirement.
- Windows NSIS installer displays and requires agreement to the terms.
- Added macOS native PKG installer with agreement page; retained DMG and ZIP formats.
- Added Linux yes/no install helper for the DEB package; retained AppImage and first-launch agreement gate.
- Added version/hash-bound first-launch consent window across platforms; declining exits and changed terms require renewed acceptance.
- Include MIT LICENSE and third-party notices with each platform's release assets; verify required formats and generate SHA-256 checksums.
- Require Windows signing and macOS Developer ID signing/notarisation secrets before public tagged releases.
- Added tests for Linux agreement acceptance/decline and release legal-document wiring.
- Native installers remain unbuilt until Node 24, dependency lockfile, dependencies, native runners, repository connection and signing credentials are available.
## Unreleased — release automation hardening

- Prevent pull-request builds from receiving Windows/macOS signing and Apple notarisation secrets.
- Keep downloaded Linux, Windows and macOS release artifacts in separate directories so identically named checksum and notice files do not overwrite one another.
- Add automated tests for Dependabot, dependency auditing, cross-platform build commands, pull-request secret isolation and release artifact separation.


## Unreleased — regression coverage and maintenance tooling (2026-11-01)

- Expanded the app catalogue regression tests to cover the ten-app scope lock, independent standalone app metadata, macOS installer targets and app launch restrictions.
- Made Linux installer agreement tests platform-aware and isolated their simulated package-manager commands.
- Added an opt-in network-backed Australian English dictionary installation and spelling integration test.
- Added an idempotent `npm run fix:app-js` maintenance command for removing legacy unused renderer fragments.


## Unreleased — Node.js 24.22.2 provisioning and developer bootstrap (2026-11-01)

- Added official Node.js 24.22.2 installers for macOS/Linux and Windows, with SHA-256 verification against the release checksum manifest before extraction.
- Added local toolchain installation that does not replace the operating system's Node.js, plus shell and PowerShell activation instructions.
- Added `npm run setup:dev` to create/verify the npm lockfile, install exact dependencies, verify licence notices and run tests.
- Updated macOS/Linux and Windows setup wrappers to provision the exact Node runtime before dependency setup.
- Updated Dev Container post-create to run the same repeatable development bootstrap.
- Recorded the owner's confirmation that Node.js 24.22.2 is a standing Brightdesk project requirement.


## Unreleased — Pages page setup foundation (2026-11-01)

- Added A4, US Letter and US Legal page presets to Brightdesk Pages.
- Added portrait and landscape orientation controls.
- Added narrow, normal, moderate and wide margin presets with saved document settings.
- Added automated tests for defaults, dimensions, margins and invalid-setting fallback.
- Pages remains a foundation build; this does not claim full Word workflow parity or production release readiness.


## Unreleased — Linux installer and Ubuntu CI compatibility (2026-11-01)

- Fixed the Linux consent helper's terms filename so it matches the legal document emitted into the release directory.
- Changed the Linux agreement tests to exercise the packaged terms filename and the Yes/No paths.
- Updated Linux CI prerequisite installation to detect current Ubuntu `t64` package names for FUSE, ALSA and ATK, while retaining support for older Ubuntu package names.
- Verification: 79 tests passed, 0 failed, 1 optional network-backed test skipped under the available Node.js 22.16.0 runtime. Native installers remain unbuilt because the exact Node.js runtime, dependency installation and a connected Brightdesk GitHub repository are not available in this workbench.
