# Brightdesk Node.js 24.22.2 development environment

Brightdesk 0.5.1 is pinned to the exact **Node.js 24.22.2 LTS** patch. Node.js 22, Node.js 24.11.1 and other patches are not accepted by the project runtime guard. Keep `.nvmrc`, `.node-version`, `package.json` `engines.node`, `.npmrc`, Dev Container and CI runner versions aligned.

## Automatic installation on macOS and Linux

From the Brightdesk project root, install the official Node.js binary and verify it against the SHA-256 value in the official release manifest:

```sh
. scripts/use-node24.sh
node --version
npm run check:node
```

The runtime is installed locally under `~/.brightdesk/toolchains/node-v24.22.2`; it does not replace the system Node.js installation. The sourceable `scripts/use-node24.sh` command installs it if needed and puts that exact version first on the current shell's `PATH`. The installer supports Linux and macOS on x64 and arm64. An optional `BRIGHTDESK_NODE_DIST_URL` can point to an approved HTTPS mirror that serves the same Node.js archive and its `SHASUMS256.txt` manifest. The installer refuses to extract the archive if the published checksum is missing or does not match.

## Automatic installation on Windows

Open PowerShell in the Brightdesk project root and dot-source the installer so it can update the current PowerShell session:

```powershell
. .\scripts\install-node24.ps1
node --version
npm run check:node
```

The Windows installer supports x64 and arm64, downloads the official ZIP and checksum manifest over HTTPS, verifies SHA-256, and installs under `$HOME\.brightdesk	oolchains
ode-v24.22.2`. It does not replace a system-wide Node installation.

## One-command dependency setup

After Node.js 24.22.2 is active:

```sh
npm run setup:dev
```

This command generates a real `package-lock.json` only when none exists, verifies the lock against `package.json`, installs the exact locked dependencies with `npm ci`, checks third-party licence notices and runs the test suite. It needs access to the npm registry the first time. It never fabricates dependency versions or integrity hashes.

The platform wrappers also perform runtime provisioning automatically before bootstrapping dependencies:

- macOS/Linux: `bash scripts/setup/install-dependencies.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File .\scripts\setup\install-dependencies.ps1`

The Dev Container uses the official `node:24.22.2-bookworm` image and runs `npm run setup:dev` after creation. That requires a working container engine and internet access from inside the container.

## Verify

```sh
node --version
npm --version
npm run check:node
npm run lock:verify
npm test
```

`node --version` must report `v24.22.2`. npm `engine-strict=true` rejects other versions when installing project dependencies.

## Dependency lockfile and CI

A genuine lockfile must be produced by npm from the exact pinned `package.json`. The three-platform GitHub Actions workflow can create the lock on a network-connected Node.js 24.22.2 runner, validate it, then pass the same lock to the Windows, macOS and Linux native build jobs. Do not hand-write a lockfile or reuse one from a different manifest.

## Platform installers

Linux installers must be built on Linux, Windows installers on Windows, and macOS installers on macOS. The existing workflow uses native GitHub-hosted runners for all three systems. Public Windows/macOS releases additionally require the configured signing and notarisation secrets. Node setup is now automated in the project, but it does not itself create installers or remove the need for a connected GitHub repository and native runners.
