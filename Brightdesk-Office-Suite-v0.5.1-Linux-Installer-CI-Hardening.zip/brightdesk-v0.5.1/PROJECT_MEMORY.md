# Brightdesk project memory and standing instructions

This file is the project-local record of the owner's continuing instructions. Read it together with `AGENTS.md`, `PRODUCT_SCOPE_LOCK.md`, `APP_IMPLEMENTATION_MATRIX.md` and `BUILD_STATUS.md` before substantial Brightdesk work.

## Owner's standing direction

- Treat every new code block, test, script, configuration or document supplied by the owner as a candidate update to the existing Brightdesk Office Suite source tree. Inspect the current implementation and integrate it into the existing project; do not treat each submission as a fresh project or overwrite unrelated working code.
- Fix defects that are exposed by the supplied code or tests. Make sensible supporting changes where required, then run the relevant tests and checks and update the source exports, changelog and build-status evidence.
- The owner has explicitly authorised use of relevant installed plugins and tools when they materially help with Brightdesk development, reverse-engineering analysis, debugging, security review, testing, build preparation or repository work. Check actual tool availability and use only relevant capabilities. Plugin installation, connection, paid actions, external account changes, publishing and other externally consequential actions remain subject to the platform's own consent and permission requirements.
- Do not claim that a plugin scan, external REA investigation, runtime trace, security review, CI workflow, native build or installer test ran unless the corresponding tool or environment produced evidence. When a preferred plugin is unavailable, use safe local checks where appropriate and clearly record the limitation.
- Keep a clear record of what changed, what passed, what failed, what was skipped, and what remains blocked. Do not describe a development snapshot as release-ready based only on source tests.

## Fixed product requirements

- Brightdesk is an independent, free, MIT-licensed productivity suite. No activation code, product key, paid subscription or account registration is required.
- The approved product catalogue is exactly ten apps: Brightdesk Pages, Brightdesk Sheets, Brightdesk Decks, Brightdesk Notes, Brightdesk Database, Brightdesk Forms, Brightdesk Lists, Brightdesk Planner, Brightdesk To Do and Brightdesk Workspace.
- Outlook, OneDrive and Teams are excluded and must not be added.
- Pages, Sheets, Decks and Notes are the only four implemented/available editor apps at the current 0.5.1 development snapshot. The other six remain planned until their implementation and acceptance checks are complete.
- Keep Brightdesk code, branding, artwork and interface assets original. Public product documentation and authorised observable workflows may inform independent implementations; do not copy proprietary source, assets, trademarks or bypass access controls.
- Preserve protected dictionary/language catalogue rules, attribution, licence checks and integrity verification.

## Current source and release baseline

- Current project line: Brightdesk Office Suite `0.5.1`, development source snapshot.
- The current build is not ready for general installation or distribution.
- **Node.js 24.22.2 LTS is the fixed project runtime** (not merely a future suggestion). `.nvmrc`, `.node-version`, `package.json` engines and `.npmrc` must stay aligned; Node.js 22 is unsupported. The project includes a Node 24 Dev Container definition, checksum-verified platform installers, and `scripts/use-node24.sh` for installing/activating the local exact runtime.
- Required release environment also includes a real committed `package-lock.json`, installed dependencies, native Windows/macOS/Linux builds, platform installation/smoke tests, and verified signing/notarisation and repository/CI configuration.
- The default runtime on the current ChatGPT build container remains Node.js 22.16.0. A separate Playwright-bundled Node.js 24.11.1 binary is available and has been used for compatibility testing, but it is not the required exact 24.22.2 patch. DNS/download access to `nodejs.org`, tested mirrors and `registry.npmjs.org` fails in this container; no Docker/Podman runtime is available to build the Dev Container. No reproducible package lock or installed Brightdesk dependency tree is present, and the connected GitHub account exposes no accessible repositories. These remain release blockers; do not invent or fabricate a lockfile or installer.
- Run `npm test`, JavaScript syntax checks, `npm run rea:inspect` for substantial source/scope changes, and licence verification when dependencies are installed. Use the platform-specific release preflight and artifact verification before describing installers as complete.
- The local Brightdesk REA Bench is static source inspection only. It is not the external REA engine, binary decompilation, runtime tracing or security certification.

## Latest supplied update (2026-11-01)

- Expanded `tests/installer-agreement.test.js` with platform-aware Linux/Bash 4+ gating and isolated Yes/No installer tests.
- Expanded `tests/app-catalog.test.js` to enforce the ten-app scope, excluded products, four available apps, separate product IDs and installer targets.
- Added opt-in `tests/dictionary-service-live.test.js` for a real pinned English (Australia) dictionary download, integrity verification and spelling check. It is skipped unless `BRIGHTDESK_LIVE_DICT_TESTS=1` and its dependencies/network are available.
- Added idempotent `scripts/fix-app-js.js` and the `npm run fix:app-js` command. The three legacy unused fragments were already absent from `src/app.js`; repeated runs correctly report them as already absent.
- Latest local verification: 65 tests passed, 0 failed, 1 opt-in live dictionary test skipped; JavaScript syntax checks passed; Linux installer shell syntax passed; local static REA Bench inspected 80 files with 0 findings after the project-memory files were added.

## Node.js 24 environment update (2026-11-01)

- Added `.devcontainer/Dockerfile` based on the official Node.js 24 Bookworm image with Linux/Electron build prerequisites, plus `.devcontainer/devcontainer.json`.
- Added `NODE24_DEVELOPMENT_ENVIRONMENT.md`, `scripts/use-node24.sh` and `scripts/check-node24.js`.
- Set `.npmrc` to `engine-strict=true`; tightened `package.json` to Node.js `24.22.2`; retained `.nvmrc` and `.node-version` at `24.22.2`.
- The default PATH remains Node.js 22.16.0. A separately bundled Node.js 24.11.1 executable was later discovered and used for compatibility tests; it does not satisfy the exact 24.22.2 project guard. `nvm install 24.22.2` could not resolve the release metadata because outbound DNS is unavailable. The Dev Container is configured but not built; no claim that Node.js 24.22.2 is installed in this host.


## Exact Node.js LTS pin and CI dependency-lock path (2026-11-01)

- Updated the project runtime pin to **Node.js 24.22.2 LTS** across `.nvmrc`, `.node-version`, `package.json` engines, `.devcontainer`, setup scripts and GitHub Actions.
- Added `scripts/verify-lockfile.js` and `lock:prepare` / `lock:verify` npm scripts. The verifier requires lockfile v3 and exact root dependency metadata matching `package.json`.
- Reworked the three-platform workflow to resolve one genuine lockfile on a network-connected Node.js 24.22.2 GitHub runner, validate it, upload it as an artifact and use the same lock in all native platform jobs via `npm ci`. The exact lockfile is included as release build metadata. No made-up lockfile or integrity values are permitted.
- Updated the security-audit workflow to generate and verify the dependency lock before running `npm ci` and `npm audit`.
- The default PATH in the current assistant container remains Node.js 22.16.0. A separate Playwright-bundled Node.js 24.11.1 binary exists, but it is older than the required exact Node.js 24.22.2 patch. No Node.js 24.22.2 runtime or Docker/Podman is available, and outbound DNS is blocked. Attempts to access `nodejs.org`, alternative Node mirrors and npm registry failed at DNS/download. A pre-existing 108 MB npm cache was inspected; it does not contain the pinned Brightdesk packages (offline lock generation stopped at uncached `docx`). The Node.js 24.22.2 release itself was independently confirmed from the official Node.js release archive.
- GitHub connector returned zero accessible repositories. Therefore no GitHub Actions run can be triggered from this connection, and no native installer build was run. The workflow is prepared, not executed.


## Owner confirmation and automatic Node.js provisioning (2026-11-01)

- The owner explicitly confirmed that Node.js **24.22.2 LTS** must remain the Brightdesk runtime and asked that this decision be remembered and implemented in the source, not merely described in chat. This is a standing project requirement for future updates.
- Do not silently downgrade to Node.js 22, accept an older Node.js 24 patch, or claim the runtime is installed without checking `node --version`. Keep `.nvmrc`, `.node-version`, `package.json` engines, `.npmrc`, Dev Container and both GitHub Actions workflows aligned at `24.22.2`.
- Added checksum-verified official Node.js installers for macOS/Linux and Windows. They install into the user's home directory and do not replace the system Node.js runtime. The shell activator and PowerShell dot-source usage make the local runtime available to the current shell.
- Added `npm run setup:dev` to create a genuine lockfile when missing, verify it, run `npm ci`, verify third-party licences and run tests. The Windows/macOS/Linux setup wrappers provision Node.js when needed before running this bootstrap. Dev Container post-create now runs the same setup.
- These additions make a connected developer machine able to provision the required runtime and dependencies. They do not bypass this isolated workbench's network restrictions and are not evidence that Node.js 24.22.2 or dependencies were installed in this workbench.


## Linux installer and Ubuntu CI compatibility update (2026-11-01)

- Fixed the Linux install helper to read `Brightdesk-Linux-TERMS_AND_CONDITIONS.txt`, matching the release asset generated by `scripts/prepare-release-assets.js`; agreement tests now use this shipped filename.
- Updated Linux Actions prerequisites to resolve current Ubuntu `t64` names for FUSE, ALSA and ATK, with fallback to pre-`t64` package names for older images.
- Latest local test result: 79 passed, 0 failed, 1 optional network-backed dictionary test skipped under Node.js 22.16.0. This is not an exact Node.js 24.22.2 run.
- No native installer build has run. The local host still lacks the exact runtime, lockfile, dependencies and Electron build tools; the connected GitHub account has no accessible Brightdesk repository.
