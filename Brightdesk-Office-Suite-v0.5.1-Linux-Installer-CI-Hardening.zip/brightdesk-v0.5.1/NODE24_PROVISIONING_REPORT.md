# Brightdesk Node.js 24.22.2 provisioning report

Date: 2026-11-01  
Project: Brightdesk Office Suite 0.5.1 development snapshot

## Target runtime

Brightdesk is pinned to Node.js **24.22.2 LTS**. The exact version is recorded in `.nvmrc`, `.node-version`, `package.json` (`engines.node`), `.devcontainer/Dockerfile`, and the GitHub Actions workflows. `.npmrc` enables strict engine enforcement. The runtime guard rejects every version except 24.22.2.

The official Node.js release archive identifies v24.22.2 as the Node 24 LTS patch released on 2026-10-28. The official Docker image publishes the `node:24.22.2-bookworm` tag.

## Provisioning attempts and result

- The default workbench `PATH` runtime is Node.js 22.16.0 with npm 10.9.2.
- `nvm install 24.22.2` was attempted. nvm could not retrieve the release list and reported that the version was not found.
- DNS lookups for `nodejs.org`, `registry.npmjs.org`, the NJU Node.js mirror, the Tsinghua mirror and `npmmirror.com` fail from this workbench. Direct download attempts also failed.
- Docker, Podman, Skopeo and Crane are not installed, so the configured Dev Container cannot be built locally.
- The environment contains a Playwright-bundled Node.js 24.11.1 executable. It was used only as a compatibility runtime; it is older than 24.22.2 and does not satisfy Brightdesk's exact-version guard.
- A Node 24.11.1 + npm CLI 10.9.2 compatibility test run passed 68 tests, failed 0 and skipped 1 opt-in network-backed dictionary test. This is not a Node.js 24.22.2 or npm 11.19.1 verification run.
- An offline lockfile generation attempt failed with `ENOTCACHED` for the pinned `docx` package metadata. No partial or fabricated `package-lock.json` was retained.

## Checks completed

- Automated test suite on bundled Node.js 24.11.1: 68 passed, 0 failed, 1 skipped.
- JavaScript syntax checks under Node.js 24.11.1: passed for all JavaScript files under `src/`, `scripts/` and `tests/`.
- Shell syntax checks: passed for Node setup, dependency setup and Linux installer scripts.
- JSON/YAML parsing: passed for Dev Container, GitHub Actions build/release, security audit and Dependabot configuration.
- Local Brightdesk REA Bench: 88 files inspected, 0 static pattern findings. This is static inspection only, not an external reverse-engineering service run, runtime trace or security certification.
- Release preflight: blocked by five verified items when run under Node.js 24.11.1: exact runtime must be 24.22.2; `package-lock.json` is missing; `node_modules` is missing; Electron is missing; and electron-builder is missing. Product scope, release metadata, terms, licence bundle, installer consent and supported native build host checks passed.

## CI and installer blockers

- The GitHub connector reports zero repositories accessible to the connected account. A public search for `brightdesk-suite` returned no matching repository. As a result, no actual workflow run can be dispatched or verified from this connection.
- The build workflow is prepared to generate one genuine dependency lock on a network-connected Node.js 24.22.2 GitHub runner, pass that same lock to native Windows, macOS and Linux runners, run checks, build the platform installers, verify files and checksums, and attach release assets for tagged releases.
- Workflow configuration has been syntax-checked locally but has not run on GitHub Actions.
- No `.exe`, `.dmg`, `.pkg`, `.zip`, `.AppImage` or `.deb` installer has been produced or installation-tested.
- Windows signing and Apple Developer ID / Installer signing and notarisation credentials are not configured or verified.

## Conclusion

The Brightdesk source and CI configuration are prepared for Node.js 24.22.2, but the exact runtime, real dependency lock, connected GitHub repository, dependencies and native installers are not available in this isolated workbench. Network restrictions cannot be removed from inside the project. No network access controls were bypassed, and no installer or runtime is claimed as complete without evidence.

The next executable route is to run this source from a connected public Brightdesk GitHub repository so GitHub-hosted Node.js 24.22.2 Linux, Windows and macOS runners can execute the prepared workflow, or to use a development machine / Dev Container that can access the official Node.js and npm distribution endpoints.


## Follow-up source implementation

After the initial provisioning investigation, the project gained executable runtime installers: `scripts/install-node24.sh` for macOS/Linux and `scripts/install-node24.ps1` for Windows. Each downloads the platform archive and official `SHASUMS256.txt` over HTTPS, compares SHA-256 before extraction, and installs under the user's home directory without replacing the system Node.js. `scripts/activate-node24.sh` activates the local runtime in a macOS/Linux shell.

The new `npm run setup:dev` bootstrap creates a real lockfile only when missing, validates it against `package.json`, runs `npm ci`, verifies licence notices and tests. Windows/macOS/Linux setup wrappers and Dev Container post-create use this bootstrap. These are source-level changes; they do not prove the runtime download or dependency installation completed in the restricted ChatGPT workbench.

The expanded regression suite then passed under the bundled Node.js 24.11.1 compatibility runtime: 73 passed, 0 failed, 1 skipped. A direct run of the new official Node installer reached the download step and then failed with DNS error 6 (`Could not resolve host: nodejs.org`); it did not extract an unverified archive or leave a partial installation. JavaScript syntax, POSIX shell syntax, installer shell syntax and JSON parsing passed. The exact-version guard correctly rejected 24.11.1. The release preflight remained blocked by five items: exact Node.js 24.22.2, missing lockfile, missing node_modules, missing Electron and missing electron-builder. A fresh static REA Bench inspection covered 93 files with 0 findings. No native installer was produced.
